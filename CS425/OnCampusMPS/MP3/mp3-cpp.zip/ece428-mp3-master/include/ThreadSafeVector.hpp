#pragma once
#include "Node.hpp"

#include <vector>
#include <chrono>
#include <mutex>
#include <iostream>

#include <boost/optional.hpp>

using T = std::pair<Node, std::chrono::steady_clock::time_point>;

class ThreadSafeVector {
public:
	ThreadSafeVector() {
	}
	~ThreadSafeVector() {
	}
	bool empty() const {
		std::lock_guard<std::mutex> lock(m);
		return data.empty();
	}
	void push(const T & value) {
		std::lock_guard<std::mutex> lock(m);
		data.push_back(value);
	}

	/**
	 * Returns a list of pairs <Node, bool>
	 * bool represents whether the node has timed out.
	 * True if time out, false if a node did not time out.
	 */
	std::vector<std::pair<Node, bool>> processTimeOuts(const boost::optional<Node> & ackReceivedNode) {
		std::vector<std::pair<Node, bool>> timedOutNodes;
		std::lock_guard<std::mutex> lock(m);
		for (auto it = data.begin(); it != data.end();) {
			std::chrono::steady_clock::time_point sentTime = it->second;
			std::chrono::steady_clock::time_point currentTime = std::chrono::steady_clock::now();

			unsigned int elpasedTime =
					std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - sentTime).count();

			if (elpasedTime <= T_FAIL_MS) {
				if (ackReceivedNode.has_value()) {
					if (ackReceivedNode == it->first) {
						// This is node that just received an ack from
						timedOutNodes.push_back(std::make_pair(it->first, false));
						it = data.erase(it);
						continue;
					}
				}
			} else {
				// Some node timed out
				timedOutNodes.push_back(std::make_pair(it->first, true));
				it = data.erase(it);
				continue;
			}
			++it;
		}
		return timedOutNodes;
	}
	bool pop(T & result) {
		std::lock_guard<std::mutex> lock(m);
		if (data.empty()) {
			return false;
		}
		result = data.back();
		data.pop_back();
		return true;
	}

private:
	const unsigned int T_FAIL_MS = 500;
	std::vector<T> data;

	mutable std::mutex m;
};

