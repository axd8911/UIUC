#pragma once

#include "Node.hpp"

#include <unordered_map>
#include <map>
#include <string>

#include <boost/serialization/access.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/map.hpp>
#include <boost/serialization/archive_input_unordered_map.hpp>
#include <boost/serialization/string.hpp>

class LocalFileDescriptor {
public:
	LocalFileDescriptor();
	LocalFileDescriptor(Node n);
	LocalFileDescriptor(const LocalFileDescriptor & other);
	~LocalFileDescriptor();

	void insertOrUpdate(std::string fileName, unsigned int version);
	void erase(std::string fileName);
	Node getNode() const;
	std::map<std::string, unsigned int> getFileNames() const;
	bool empty() const;

private:
	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive & ar, const unsigned int version) {
		ar & node;
		ar & fileNames;
	}
	Node node;
	std::map<std::string, unsigned int> fileNames;
};
