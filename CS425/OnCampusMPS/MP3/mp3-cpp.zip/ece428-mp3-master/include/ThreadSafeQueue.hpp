#pragma once

#include <queue>
#include <mutex>

template<class T>
class ThreadSafeQueue
{
public:
    ThreadSafeQueue() {};
    ~ThreadSafeQueue() {};
    bool empty() const
    {
        std::lock_guard<std::mutex> lock(m);
        return data.empty();
    };
    void push(const T & value)
    {
        std::lock_guard<std::mutex> lock(m);
        data.push(value);
    }
    bool pop(T & result)
    {
        std::lock_guard<std::mutex> lock(m);
        if(data.empty())
        {
            return false;
        }
        result = data.front();
        data.pop();
        return true;
    }

private:
    std::queue<T> data;

    mutable std::mutex m;
};

