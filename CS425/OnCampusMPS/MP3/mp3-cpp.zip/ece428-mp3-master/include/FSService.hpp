#pragma once

#include "FDService.hpp"
#include "FSHeader.hpp"
#include "FileDescriptor.hpp"
#include "LocalFileDescriptor.hpp"
#include "Node.hpp"
#include "MasterNode.hpp"

#include <memory>
#include <string>
#include <atomic>
#include <vector>
#include <functional>
#include <mutex>
#include <chrono>

#include <boost/lockfree/spsc_queue.hpp>
#include <boost/asio.hpp>

using boost::asio::ip::tcp;

using ReplicaQueue = boost::lockfree::spsc_queue<char, boost::lockfree::capacity<819200>>;

class FSService {
public:
	FSService(unsigned short portFD, unsigned short portFS,
			std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines, bool logVerbose,
			bool falsePositiveTest);
	~FSService();

	void startService();
	std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher>>> getFileDescriptor() const;
	LocalFileDescriptor getLocalFileDescriptor() const;
	bool amIMaster() const;

	std::shared_ptr<FDService> getFDService() const;

private:
	const unsigned int DESIRED_REPLICA_COUNT = 4;

	unsigned short portFS;
	std::string dirName;
	std::shared_ptr<boost::asio::thread_pool> pool;
	std::shared_ptr<FDService> fds;
	std::shared_ptr<FileDescriptor> fileDescriptor;
	/**
	 * Callback for the failure detector service to trigger file system changes, namely replications processes
	 */
	std::function<void(std::vector<Node>, std::vector<Node> members, Node thisMachine, std::vector<Node> failedNodes)> reelectMaster;
	std::atomic<bool> amMaster = { false };
	MasterNode masterNode;
	std::atomic_flag rebuildStarted = ATOMIC_FLAG_INIT;

	mutable std::mutex localFileDescMutex;
	std::shared_ptr<LocalFileDescriptor> localFileDesc;

	void startServicePrivate();
	void processRequest(std::shared_ptr<tcp::socket> soc);
	void sendHeader(tcp::socket& soc, const FSHeader& fsh);
	std::string make_string(boost::asio::streambuf& streambuf);
	void findNRandomAliveNodes(int n, std::vector<Node> & result);
	void replicate(ReplicaQueue& queue, std::vector<Node> & nodes, FSHeader& replicaHeader,
			std::vector<Node> & ackedNodes);
	void coordinateReplication();
	void getRereplicationCandidates(const MembersType & members,
			const std::unordered_set<Node, NodeHasher> & existingReplicas, std::vector<Node> & result);

};

