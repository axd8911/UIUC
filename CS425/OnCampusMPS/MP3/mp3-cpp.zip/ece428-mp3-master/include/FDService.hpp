#pragma once

#include "Header.hpp"
#include "ThreadSafeMap.hpp"
#include "ThreadSafeVector.hpp"
#include "NodeStatus.hpp"

#include <memory>
#include <vector>
#include <string>
#include <chrono>
#include <atomic>
#include <unordered_map>
#include <fstream>
#include <mutex>

#include <boost/asio.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/optional.hpp>

class FDService {
public:
	const int PING_WAIT_MS = 1000;

	FDService(unsigned short port, unsigned short portFS,
			std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines, bool logVerbose,
			bool falsePositiveTest,
			std::function<
					void(std::vector<Node>, std::vector<Node> members, Node thisMachine, std::vector<Node> failedNodes)> reelectMasterCallback);
	~FDService();

	bool setupService();
	bool startService();
	std::unordered_map<Node, NodeStatus, NodeHasher> getMembers();
	void leave();
	Node getThisMachine();

private:
	const int PING_NODES_COUNT = 3;

	std::atomic<bool> haveJoined;
	std::atomic<bool> haveLeft;
	std::shared_ptr<Node> thisMachine;
	std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines;
	std::string myAddr;
	std::atomic<unsigned int> pingSent;
	ThreadSafeMap members;
	boost::lockfree::spsc_queue<std::pair<Node, NodeStatus>, boost::lockfree::capacity<1024>> dissemQueue;
	std::vector<Node> contacts;
	ThreadSafeVector ackExpectations;
	unsigned short port, portFS;

	std::shared_ptr<boost::asio::thread_pool> senderPool;
	std::function<void(std::vector<Node>, std::vector<Node> members, Node thisMachine, std::vector<Node> failedNodes)> reelectMasterCallback;

	bool waitForSingleAck(std::atomic<bool> & listeningFlag, const Header& header, const Node & targetNode,
			unsigned int timeOutMs);
	void pingListener(unsigned short port);
	void handleReceivedHeader(Header & header);
	void processReceivedHeader(Header & header);
	void sendHeader(const Node & n, const Header & h);
	void pingSender();
	boost::optional<Node> getNextContact();
	void checkTimeOuts(const boost::optional<Node> & ackReceivedNode);
	void reelectMaster(std::vector<Node> newNodes, std::vector<Node> failedNodes);

	void writeLocalLog(char type, char status, const Node &node);
	void writeEventLog(char type, const Node &node);

	bool logVerbose;
	std::mutex logLock;
	std::ofstream f_log;

	bool falsePositiveTest;
};
