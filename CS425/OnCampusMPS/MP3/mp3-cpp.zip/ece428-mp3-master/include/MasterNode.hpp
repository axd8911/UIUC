#pragma once

#include "Node.hpp"

#include <mutex>

class MasterNode {
public:
	MasterNode();
	~MasterNode();

	// Return true if master node has been changed
	bool update(Node n);
	Node get();

private:
	Node node;

	mutable std::mutex m;
};
