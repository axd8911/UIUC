#pragma once
enum class NodeStatus{
	EMPTY,
    NEW,
    ALIVE,
    SUSPECTED,
    FAILED,
    LEAVE,
	PONG
};
