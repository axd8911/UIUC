
#pragma once

#include "FSMessageType.hpp"
//#include "NodeStatus.hpp"
#include "Node.hpp"
//#include "ThreadSafeMap.hpp"

#include <unordered_map>
#include <vector>

#include <boost/serialization/access.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/string.hpp>

class FSHeader
{
public:
    FSHeader();
    FSHeader(FSMessageType t, std::string fn);
    FSHeader(FSMessageType t, std::string fn, uint32_t vn);
    ~FSHeader();


    FSMessageType getFSMessageType () const;
    uint32_t getVersionNum () const;
    std::string getFileName() const;
    void setFileSize(const unsigned long size);
    unsigned long getFileSize() const;
    void getLsResult();
    std::vector<Node> getNodes() const;

    void insertNode(Node node);

private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
        ar & type;
        ar & nodes;
        ar & sdfsfilename;
        ar & fileSize;
        ar & numVersions;
    }

    FSMessageType type;
    std::vector<Node> nodes;
    std::string sdfsfilename;
    uint32_t numVersions;
    unsigned long fileSize;
};
