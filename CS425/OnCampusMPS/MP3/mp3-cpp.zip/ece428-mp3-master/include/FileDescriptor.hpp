#pragma once

#include "Node.hpp"
#include "LocalFileDescriptor.hpp"

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <mutex>

#include <boost/serialization/access.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/unordered_set.hpp>
#include <boost/serialization/vector.hpp>

class FileDescriptor {
public:
	FileDescriptor();
	~FileDescriptor();

	bool insertOrUpdate(std::string fileName, std::vector<Node> & nodes, unsigned int version);
	bool deleteFile(std::string fileName);
	bool update(std::string filename);
	bool change(std::string filename, Node& node);
	bool fail(Node& node);
	bool fileExist(std::string fileName);
	std::pair<uint32_t, std::unordered_set<Node, NodeHasher>> getDescriptor(std::string fileName);
	void insertFromOther(LocalFileDescriptor &otherLocal);
	std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher>>> getData() const;

private:
	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive & ar, const unsigned int version) {
		ar & descriptor;
	}

	std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher>>> descriptor;
	mutable std::mutex m;
};
