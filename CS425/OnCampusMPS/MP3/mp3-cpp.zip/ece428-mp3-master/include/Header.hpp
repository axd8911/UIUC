#pragma once

#include "MessageType.hpp"
#include "NodeStatus.hpp"
#include "Node.hpp"
#include "ThreadSafeMap.hpp"

#include <unordered_map>

#include <boost/serialization/access.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>

class Header
{
public:
    Header();
    Header(MessageType t);
    ~Header();

    void insert(const Node & node, const NodeStatus status);
    void copyFromMembershipList(const ThreadSafeMap & tsm);

    MessageType getMessageType () const;
    std::size_t nodesSize() const;

    Node getFirst() const;

    std::unordered_map<Node, NodeStatus, NodeHasher>::iterator begin() noexcept;

    std::unordered_map<Node, NodeStatus, NodeHasher>::iterator end() noexcept;

private:
    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
        ar & type;
        ar & nodes;
    }

    MessageType type;
	std::unordered_map<Node, NodeStatus, NodeHasher> nodes;
};
