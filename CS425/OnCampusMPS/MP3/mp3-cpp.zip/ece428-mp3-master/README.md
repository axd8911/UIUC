# ece428-mp3

MP3 for ECE428/CS425

We wrote our MP in C++ using Boost library 1.68.0.
So a successful compilation requires Boost to be compiled first with the following static libraries:

- system
- thread
- date_time
- regex
- serialization
- filesystem

## Compile

1. Make sure Boost is install and environment variable BOOST_PATH is set (without the final slash). If not, follow the steps in `README` document of our MP1.

1. `make` This will compile both server and the client and you can find those binaries in the root directory. If you wish to only compile on or the other, do `make client` or `make server`. You can speed up the compilation by using multiple threads (on an i7 4th gen `make -j4 all` cuts down compile time from 28 seconds to 11 seconds).


## Start the Services

### Server

1. `cd` into the root directory.

1. Run `./server [FD port number]  [address book]  [FS port number]`, where
	- [FD port number] is the UDP port the program is going to use for failure detection service from MP2.
	- [address book] Two address books are used for easy local and remote (VM) testing.
		- machine_addr.txt for local testing
		- machine_addr_vm.txt for running on VM clusters
	- [FS port number] is the port where the File system operations will take in TCP requests.
	
	If you're not sure what ports to use, just use the default 8009 for FD port and 8100 for FS port, These ports need to be matched in the address books as well.

1. Once the server is running, you can enter commands to the program.
	- `members` or `m` will list the members that is in the distributed system.
	- `id` or `i` will list the information about the node itself.
	- `leave` will make the node voluntarily leave.
	- `ls` will list the files that are stored on the current node.
	- `ls-master` or `lm` will list all the files and their replica locations in the distributed system. This command will not do anything if executed on a node that is not the master.

### Client

1. `cd` into the root directory.

1. Run `./client [command] [address book] `, where
	- [command] can be several things:
		- `put localfilename sdfsfilename` will put or update a local file specified to the distrbuted system.
		- `get sdfsfilename localfilename` will get a file in the distrbuted system with the latest version and store it in the local file under results folder.
		- `delete sdfsfilename` will delete a file and all its versions from the distributed system.
		- `ls sdfsfilename`will list where replicas of a file are stored.
		- `get-versions sdfsfilename num-versions localfilename` will get number of the latest version specified of a file and store them to files in the results folder
	- [address book] Two address books are used for easy local and remote (VM) testing.
		- machine_addr.txt for local testing
		- machine_addr_vm.txt for running on VM clusters
