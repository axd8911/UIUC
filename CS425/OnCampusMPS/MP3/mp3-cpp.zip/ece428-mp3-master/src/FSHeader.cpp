#include "FSHeader.hpp"

#include <stddef.h>
#include <utility>
#include <iostream>

FSHeader::FSHeader()
{
}

FSHeader::FSHeader(FSMessageType t, std::string fn) 
    : type(t),
      sdfsfilename(fn),
      numVersions(100),
	  fileSize(0)
{
}

FSHeader::FSHeader(FSMessageType t, std::string fn, uint32_t vn) 
    : type(t),
      sdfsfilename(fn),
      numVersions(vn),
	  fileSize(0)
{
}

FSHeader::~FSHeader()
{
}


FSMessageType FSHeader::getFSMessageType() const
{
    return type;
}

uint32_t FSHeader::getVersionNum() const
{
    return numVersions;
}

void FSHeader::getLsResult()
{
    std::cout << "the VMs where this file is currently being stored:" << std::endl;
    for(auto i = nodes.begin(); i != nodes.end(); ++ i){
        std::cout << *i << std::endl;
    }

    std::cout << "****************" << std::endl;

    return;
}

std::string FSHeader::getFileName() const {
	return this->sdfsfilename;
}

void FSHeader::setFileSize(const unsigned long size) {
	this->fileSize = size;
}

unsigned long FSHeader::getFileSize() const {
	return this->fileSize;
}

std::vector<Node> FSHeader::getNodes() const {
	return nodes;
}

void FSHeader::insertNode(Node node)
{
    nodes.push_back(node);

    return;
}
