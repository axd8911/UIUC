#include "Node.hpp"

#include <string>

#include <boost/uuid/detail/sha1.hpp>

Node::Node() {

}

Node::Node(std::string theirAddress, unsigned short theirPort, unsigned short theirFSPort,
		unsigned long theirJoinTime, unsigned int vInc) {
	this->theirAddress = theirAddress;
	this->theirPort = theirPort;
	this->theirFSPort = theirFSPort;
	this->theirJoinTime = theirJoinTime;
	this->vIncarnation = vInc;

	boost::uuids::detail::sha1 s1;
	std::string msg = theirAddress + std::to_string(theirPort)
			+ std::to_string(theirJoinTime);
	s1.process_bytes(msg.data(), msg.size());
	unsigned int digest[5] = { 0 };
	s1.get_digest(digest);
	// The ID of the node is the first 4 bytes of the SHA1 hash of its information
	this->uuid = digest[0];
}

Node::Node(std::string theirAddress, unsigned short theirPort, unsigned short theirFSPort,
		unsigned long theirJoinTime, unsigned int vInc, unsigned int uuid) {
	this->theirAddress = theirAddress;
	this->theirPort = theirPort;
	this->theirFSPort = theirFSPort;
	this->theirJoinTime = theirJoinTime;
	this->uuid = uuid;
	this->vIncarnation = vInc;
}

Node::Node(const Node & other) {
	this->theirAddress = other.theirAddress;
	this->theirPort = other.theirPort;
	this->theirFSPort = other.theirFSPort;
	this->theirJoinTime = other.theirJoinTime;
	this->uuid = other.uuid;
	this->vIncarnation = other.vIncarnation;
}

bool Node::operator==(const Node& other) const {
	return theirAddress == other.theirAddress && theirPort == other.theirPort
			&& theirJoinTime == other.theirJoinTime;
}

bool Node::weakEquals(const Node& other) const {
	return theirAddress == other.theirAddress && theirPort == other.theirPort;
}

Node::~Node() {
}

std::ostream& operator<<(std::ostream& os, const Node& n)
{
    os << n.getTheirAddress() << ':' << n.getTheirPort();;
    return os;
}

unsigned int Node::getUUID() const {
	return this->uuid;
}

std::string Node::getTheirAddress() const {
	return this->theirAddress;
}

unsigned short Node::getTheirPort() const {
	return this->theirPort;
}

unsigned short Node::getTheirFSPort() const {
	return this->theirFSPort;
}

unsigned int Node::getVInc() const {
	return this->vIncarnation;
}

unsigned long Node::getTheirJoinTime() const {
	return this->theirJoinTime;
}

void Node::setVInc(unsigned int vInc) {
	this->vIncarnation = vInc;
}

void Node::incVInc() {
	++this->vIncarnation;
}
