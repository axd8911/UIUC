// STL
#include <iostream>
#include <memory>
#include <vector>
#include <string>
#include <fstream>
#include <utility>
#include <iomanip>
#include <unordered_map>

// Boost
#include <boost/lexical_cast.hpp>

#include "../include/FDService.hpp"
#include "../include/FSService.hpp"
#include "LocalFileDescriptor.hpp"
#include "FileDescriptor.hpp"

using Machines = std::vector<std::pair<std::string, std::string>>;

const int MIN_ARG_COUNT = 4;

int main(int argc, char * argv[]) {
	// Check args
	if (argc < MIN_ARG_COUNT) {
		std::cout << "Usage: " << argv[0] << " <FD port number>" << " <address file>" << " <FS port number>"
				<< std::endl;
		return 1;
	}
	// Assign ports
	unsigned short fdPortNum = boost::lexical_cast<unsigned short>(argv[1]);
	unsigned short fsPortNum = boost::lexical_cast<unsigned short>(argv[3]);

	// Read optional params
	bool logVerbose = false;
	bool falsePositiveTest = false;
	for (int i = MIN_ARG_COUNT; i < argc; ++i) {
		std::string arg;
		arg.assign(argv[i]);
		if (arg == "-v" || arg == "--verbose") {
			logVerbose = true;
		} else if (arg == "-f" || arg == "--false-positive-test") {
			falsePositiveTest = true;
		}
	}

	// Read in the other server addresses for failture detector
	std::string addrFileName;
	addrFileName.assign(argv[2]);
	std::shared_ptr<Machines> machine_addr = std::make_shared<Machines>();
	std::fstream addr_file;
	std::string temp;
	addr_file.open(addrFileName, std::ios::in);

	while (!addr_file.eof()) {
		std::getline(addr_file, temp);
		if (temp[0] == '-' || temp[0] == '#') {
			// If the first char is a dash or a pound sign, then ignore this line
			// This allows for commenting in the address file
			continue;
		}

		std::vector<std::string> machineAddrParts;
		std::string delimiter = ":";
		std::string token;
		std::size_t pos = 0;
		while ((pos = temp.find(delimiter)) != std::string::npos) {
			token = temp.substr(0, pos);
			machineAddrParts.push_back(token);
			temp.erase(0, pos + delimiter.length());
		}
		machineAddrParts.push_back(temp);
		if (machineAddrParts.size() != 3) {
			// Mal-formed machine addr file
			continue;
		}

		std::string addr = machineAddrParts[0];
		std::string portFD = machineAddrParts[1];
		std::string portFS = machineAddrParts[2];
		machine_addr->push_back(std::make_pair(addr, portFD));
	}
	addr_file.close();

	// Start the File System Service
	std::shared_ptr<FSService> fss = std::make_shared<FSService>(fdPortNum, fsPortNum, machine_addr, logVerbose,
			falsePositiveTest);
	std::shared_ptr<FDService> fds = fss->getFDService();

	fss->startService();

	// Get command line input
	std::string lastCmd;
	while (true) {
		if (falsePositiveTest) {
			break;
		}
		std::cout << "Enter a command: " << std::endl;
		std::string cmd;
		std::getline(std::cin, cmd);
		std::vector<std::string> cmdList;

		// Pressing enter without input will execute the last command (like gdb)
		if (cmd.empty()) {
			cmdList.push_back(lastCmd);
		} else {
			// Parse new command
			std::string delimiter = " ";
			std::string token;
			std::size_t pos = 0;
			while ((pos = cmd.find(delimiter)) != std::string::npos) {
				token = cmd.substr(0, pos);
				cmdList.push_back(token);
				cmd.erase(0, pos + delimiter.length());
			}
			cmdList.push_back(cmd);
		}

		if (cmdList[0] == "leave") {
			// Leave the network
			fds->leave();
			break;
		} else if (cmdList[0] == "members" || cmdList[0] == "m") {
			// Display the members in stdout
			std::unordered_map<Node, NodeStatus, NodeHasher> membersCopy = fds->getMembers();
			std::cout << std::setw(2) << "" << "||" << std::setw(8) << "ID" << "||" << std::setw(15) << "Address"
					<< "||" << std::setw(5) << "Port" << "||" << " vIncarnation" << std::endl;
			int i = 1;
			std::for_each(membersCopy.begin(), membersCopy.end(),
					[&](std::pair<const Node, NodeStatus> &m)
					{
						Node n = m.first;
						std::cout <<std::setw(2) << i << "||" << std::setw(8) << std::hex << n.getUUID() << "||" << std::setw(15) << n.getTheirAddress() << "||" <<
						std::dec << std::setw(5) << n.getTheirPort() << "||" << n.getVInc() << std::endl;
						++i;
					});
		} else if (cmdList[0] == "i" || cmdList[0] == "id") {
			// Display this machine's status
			std::cout << std::setw(2) << "" << "||" << std::setw(8) << "ID" << "||" << std::setw(15) << "Address"
					<< "||" << std::setw(5) << "Port" << "||" << " vIncarnation" << std::endl;
			Node n = fds->getThisMachine();
			std::cout << std::setw(2) << 1 << "||" << std::setw(8) << std::hex << n.getUUID() << "||" << std::setw(15)
					<< n.getTheirAddress() << "||" << std::dec << std::setw(5) << n.getTheirPort() << "||"
					<< n.getVInc() << std::endl;

		} else if (cmdList[0] == "ls") {
			LocalFileDescriptor localFileDesc = fss->getLocalFileDescriptor();
			std::map<std::string, unsigned int> fileNames = localFileDesc.getFileNames();
			std::cout << std::setw(10) << "File Name" << "||" << "Version" << std::endl;
			for (auto fileName : fileNames) {
				std::cout << std::setw(10) << fileName.first << "||" << fileName.second << std::endl;
			}
		} else if (cmdList[0] == "ls-master" || cmdList[0] == "lm") {
			if (fss->amIMaster()) {
				std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher>>> fileDesc =
						fss->getFileDescriptor();

				std::cout << std::setw(10) << "File Name" << "||" << std::setw(7) << "Version" << "||" << std::setw(8)
						<< "Replicas" << std::endl;
				for (auto files : fileDesc) {
					std::cout << std::setw(10) << files.first << "||" << std::setw(7) << files.second.first << "||"
							<< std::setw(8) << "" << std::endl;
					std::unordered_set<Node, NodeHasher> nodesSet = files.second.second;
					for (auto nodes = nodesSet.begin(); nodes != nodesSet.end(); ++nodes) {
						std::cout << std::setw(10) << "" << "||" << std::setw(7) << "" << "||" << std::setw(8) << *nodes
								<< std::endl;
					}
				}
			}
		} else if (cmdList[0] == "") {
			// Nothing
		} else {
			std::cout << "Did not recognize that command" << std::endl;
		}
		lastCmd = cmdList[0];
	}
}

