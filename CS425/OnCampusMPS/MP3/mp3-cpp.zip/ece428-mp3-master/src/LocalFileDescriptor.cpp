#include "LocalFileDescriptor.hpp"

LocalFileDescriptor::LocalFileDescriptor() {
}

LocalFileDescriptor::LocalFileDescriptor(Node n) {
	this->node = n;
}

LocalFileDescriptor::LocalFileDescriptor(const LocalFileDescriptor& other) {
	this->node = other.node;
	for(auto fn : other.fileNames){
		this->fileNames.insert(fn);
	}
}

LocalFileDescriptor::~LocalFileDescriptor() {
}

void LocalFileDescriptor::insertOrUpdate(std::string fileName, unsigned int version) {
	auto search = fileNames.find(fileName);
	if (search == fileNames.end()) {
		fileNames.insert( { fileName, version });
	} else {
		search->second = version;
	}
	return;
}

void LocalFileDescriptor::erase(std::string fileName) {
	auto search = fileNames.find(fileName);
	if (search != fileNames.end()) {
		fileNames.erase(search);
	}
	return;
}

Node LocalFileDescriptor::getNode() const {
	return node;
}

std::map<std::string, unsigned int> LocalFileDescriptor::getFileNames() const {
	return fileNames;
}

bool LocalFileDescriptor::empty() const {
	return fileNames.empty();
}
