#include "FSService.hpp"

#include "FSMessageType.hpp"
#include "NodeStatus.hpp"

#include <iostream>
#include <thread>
#include <algorithm>
#include <random>
#include <cassert>
#include <unordered_set>

#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/ptime.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>
#include <boost/array.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/iostreams/device/array.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/utility.hpp>
#include <boost/thread.hpp>

struct NodeCompare {
	bool operator()(Node i, Node j) {
		if (i.getTheirAddress() == j.getTheirAddress()) {
			return i.getTheirPort() < j.getTheirPort();
		}
		return i.getTheirAddress() < j.getTheirAddress();
	}
} NodeCompare;

const unsigned int BYTES_SIZE = 8192;

FSService::FSService(unsigned short portFD, unsigned short portFS,
		std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines, bool logVerbose,
		bool falsePositiveTest) {
	pool = std::make_shared<boost::asio::thread_pool>(4);
	reelectMaster =
			[this](std::vector<Node> newNodes, std::vector<Node> members, Node thisMachine, std::vector<Node> failedNodes) {
				std::vector<Node> allNodes;
				for(auto n : members) {
					allNodes.push_back(n);
				}
				for(auto n : newNodes) {
					allNodes.push_back(n);
				}
				allNodes.push_back(thisMachine);
				std::sort(allNodes.begin(), allNodes.end(), NodeCompare);
				if(masterNode.update(allNodes.front())) {
					// If master node changed, send new master node local file desc, only if I have local files stored
					bool localFilesEmpty;
					{
						std::lock_guard<std::mutex> lk(localFileDescMutex);
						localFilesEmpty = localFileDesc->empty();
					}
					if(!localFilesEmpty) {
						FSHeader failedNodesHeader(FSMessageType::PARTIAL_FILE_DESC, "Nodes Changed");
						/*for(auto n : *failedNodes) {
						 failedNodesHeader.insertNode(n);
						 }*/
						boost::asio::io_context ioservice;
						tcp::resolver resolv(ioservice);
						tcp::resolver::query q(masterNode.get().getTheirAddress(),
								std::to_string(masterNode.get().getTheirFSPort()));
						tcp::resolver::results_type endpoints = resolv.resolve(q);
						std::shared_ptr<tcp::socket> soc = std::make_shared<tcp::socket>(ioservice);
						try {
							boost::asio::connect(*soc, endpoints);
						} catch (const boost::system::system_error & ec) {
							return;
						}
						sendHeader(*soc, failedNodesHeader);
						std::array<char, 8192> recvBytes;
						// Temp measure like explained
						boost::system::error_code ec;
						soc->read_some(boost::asio::buffer(recvBytes), ec);
						// Send local file desc
						std::ostringstream sendBuf;
						{
							boost::archive::binary_oarchive ar(sendBuf);
							std::lock_guard<std::mutex> lk(localFileDescMutex);
							ar << (*localFileDesc);
						}
						boost::asio::write(*soc, boost::asio::buffer(sendBuf.str()), ec);
						soc->close(ec);
					}
				}
				amMaster.store(masterNode.get() == thisMachine);
				std::cout << "Reelected " << masterNode.get().getTheirAddress() << ":" << masterNode.get().getTheirFSPort() << std::endl;
				if(amMaster.load()) {
					// I am the master, dont't send partial file descriptor
					if(rebuildStarted.test_and_set() == false) {
						// Rebuild has not been started before
						boost::asio::post(*pool, [this] {
									// Wait for two times the T_fail to start the rebuilding
									// so all of the local file descriptors by then should be received
									boost::this_thread::sleep(boost::posix_time::milliseconds(4 * fds->PING_WAIT_MS));
									this->coordinateReplication();
									rebuildStarted.clear();
								});
					};
					for(Node n : failedNodes) {
						fileDescriptor->fail(n);
					}
					return;
				}
			};
	// Start the failure detector service
	fds = std::make_shared<FDService>(portFD, portFS, machines, logVerbose, falsePositiveTest, reelectMaster);
	this->portFS = portFS;

	// Create the directory where all the files go
	this->dirName = "sdfs_" + fds->getThisMachine().getTheirAddress() + ":"
			+ std::to_string(fds->getThisMachine().getTheirFSPort());
	boost::filesystem::path dir(dirName);
	// Remove all the files stored from the last run
	boost::system::error_code ecIgnored;
	boost::filesystem::remove_all(dir, ecIgnored);
	boost::filesystem::create_directory(dir);

	// Allocate the file descriptor object
	fileDescriptor = std::make_shared<FileDescriptor>();
	localFileDesc = std::make_shared<LocalFileDescriptor>(fds->getThisMachine());

	fds->startService();
}

FSService::~FSService() {
}

void FSService::startService() {
	boost::thread service([this] {
		startServicePrivate();
	});
	service.detach();
}

std::shared_ptr<FDService> FSService::getFDService() const {
	return this->fds;
}

void FSService::processRequest(std::shared_ptr<tcp::socket> soc) {
	FSHeader requestHeader;
	std::array<char, 1024> initialBytes;
	boost::system::error_code initialEc;
	soc->read_some(boost::asio::buffer(initialBytes), initialEc);
	if (initialEc) {
		// The client shut it down
		return;
	}
	{
		boost::iostreams::array_source source(initialBytes.begin(), initialBytes.end());
		boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
		boost::archive::binary_iarchive ia(inputStream);
		ia >> requestHeader;
	}

	// This is a temporary measure, I have to send something here and have the client receive it
	// Other wise the read_some below in the while loop may not receive anything
	soc->write_some(boost::asio::buffer(initialBytes));

	switch (requestHeader.getFSMessageType()) {
	case FSMessageType::PUT: {
		// Prepare for file transfer
		unsigned long fileSize = requestHeader.getFileSize();
		unsigned long sizeRead = 0;
		std::string fileName = requestHeader.getFileName();
		ReplicaQueue replicaQueue;
		std::vector<Node> replicaNodes;

		// Determine the version number of this incoming file
		std::pair<unsigned int, std::unordered_set<Node, NodeHasher>> descrip = fileDescriptor->getDescriptor(fileName);
		unsigned int version = descrip.first;
		if (version == 0) {
			// This is a new file
			findNRandomAliveNodes(DESIRED_REPLICA_COUNT, replicaNodes);
		} else {
			for (auto n : descrip.second) {
				replicaNodes.push_back(n);
			}
		}
		// Increment version. Version number always starts at 1
		++version;
		FSHeader replicaHeader(FSMessageType::REPLICATE, requestHeader.getFileName(), version);
		replicaHeader.setFileSize(fileSize);
		std::vector<Node> ackedNodes;
		boost::thread repliateThread([&]() {
			replicate(replicaQueue, replicaNodes, replicaHeader, ackedNodes);
		});

		std::cout << "Expected file size = " << fileSize << std::endl;
		std::string messageRead = "";
		while (true) {
			std::array<char, 8192> bytesRecv;
			boost::system::error_code ec;
			boost::asio::streambuf read_buffer;

			std::size_t bytesRead = soc->read_some(boost::asio::buffer(bytesRecv), ec);

			//std::size_t bytesRead = boost::asio::read(*soc, read_buffer, boost::asio::transfer_at_least(1), ec);
			if (ec == boost::asio::error::eof) {
				std::cout << "The other end shut down" << std::endl;
				break;
			}
			for (std::size_t j = 0; j < bytesRead; ++j) {
				// Process each byte received
				// Push to the queue until successful
				while (!replicaQueue.push(bytesRecv[j])) {
				}
				messageRead += bytesRecv[j];
			}
			//std::cout << "Received" << bytesRead << " " << ec.message() << std::endl;
			sizeRead += bytesRead;
			if (sizeRead >= fileSize) {
				break;
			}
		}
		std::cout << "File received" << std::endl;

		repliateThread.join();

		if (ackedNodes.size() != replicaNodes.size()) {
			// Not all replica nodes acked the replication
			// TODO: get new replica nodes
		}

		if (ackedNodes.size() < DESIRED_REPLICA_COUNT) {
			// Not enough replicas made
			// Write to self
			std::ofstream f(dirName + "/" + fileName + ((version == 100) ? "" : std::to_string(version)));
			f << messageRead;
			f.flush();
			// Add self to ackedNodes
			ackedNodes.push_back(fds->getThisMachine());
			// Add to local file descriptor
			{
				std::lock_guard<std::mutex> lk(localFileDescMutex);
				localFileDesc->insertOrUpdate(fileName, version);
				fileDescriptor->insertFromOther(*localFileDesc);
			}
		}

		fileDescriptor->insertOrUpdate(fileName, ackedNodes, version);

		FSHeader ackHeader(FSMessageType::ACK, "Finished ACK");

		sendHeader(*soc, ackHeader);
	}
		break;
	case FSMessageType::GET: {

		//as long as the GET from current replica fails, we will terminate the procedure and let the client to resend the request (to the same master node)
		std::string sfn = requestHeader.getFileName();
		uint32_t nv = requestHeader.getVersionNum();

		if (nv == 100) {
			// Get the latest version
			// If the file doesn't exist, it will fail later
			{
				std::lock_guard<std::mutex> lk(localFileDescMutex);
				std::map<std::string, unsigned int> fileNamesMap = localFileDesc->getFileNames();
				auto search = fileNamesMap.find(sfn);
				if (search != fileNamesMap.end()) {
					nv = search->second;
				}
			}
		}

		std::array<char, BYTES_SIZE> bytes;
		boost::system::error_code ec;
		// Wait for client's reply to send getResponse
		soc->read_some(boost::asio::buffer(bytes), ec);

		std::ifstream ifs;
		ifs.open(dirName + "/" + sfn + std::to_string(nv), std::ifstream::in | std::ios::binary | std::ios::ate);

		if (ifs.is_open()) {
			//std::cout << "Opening " << sfn << " to replicate to others" << std::endl;
			unsigned long size = ifs.tellg();

			ifs.seekg(0);

			FSHeader getResponseHeader(FSMessageType::GET_RESPONSE_OK, sfn, nv);
			getResponseHeader.setFileSize(size);
			getResponseHeader.setFileSize(size);
			sendHeader(*soc, getResponseHeader);

			// Wait for the other to receive the get header response and ack
			soc->read_some(boost::asio::buffer(bytes), ec);

			while (size > 0) {
				int readSize = ((size > BYTES_SIZE) ? BYTES_SIZE : size);
				size = size - readSize;
				ifs.read(bytes.data(), readSize);

				boost::asio::write(*soc, boost::asio::buffer(bytes), boost::asio::transfer_exactly(readSize), ec);
				//std::cout << "Sent " << readSize << " left " << size << std::endl;
				if (ec) {
					return;
				}
			}
			ifs.close();
			// Receive the ACK header, no need to check
			soc->read_some(boost::asio::buffer(bytes), ec);
		} else {
			if (!fileDescriptor->fileExist(sfn)) {
				// File does not exist
				FSHeader getResponseHeader(FSMessageType::GET_RESPONSE_BAD, sfn, nv);
				sendHeader(*soc, getResponseHeader);
				return;
			}
			auto search = fileDescriptor->getDescriptor(sfn);
			if (nv == 100) {
				// Get the newest version
				nv = search.first;
			} else if (search.first < nv) {
				// Version not correct
				FSHeader getResponseHeader(FSMessageType::GET_RESPONSE_BAD, sfn, nv);
				sendHeader(*soc, getResponseHeader);
				return;
			}
			if (search.second.size() == 0) {
				// There are no replicas of such file
				FSHeader getResponseHeader(FSMessageType::GET_RESPONSE_BAD, sfn, nv);
				sendHeader(*soc, getResponseHeader);
				return;
			}
			// nv may be 100, but that's okay
			FSHeader getResponseHeader(FSMessageType::GET_RESPONSE_REDIRECT, sfn, nv);
			getResponseHeader.insertNode(*search.second.begin());
			sendHeader(*soc, getResponseHeader);
		}

	}
		break;
	case FSMessageType::LS: {
		std::string sfn = requestHeader.getFileName();

		std::array<char, BYTES_SIZE> bytesRecv;
		boost::system::error_code ec;
		// wait for client reply to send LS
		soc->read_some(boost::asio::buffer(bytesRecv), ec);

		FSHeader resultHeader(FSMessageType::LS, sfn);
		if (fileDescriptor->fileExist(sfn) == true) {
			auto search = fileDescriptor->getDescriptor(sfn);

			for (auto i = search.second.begin(); i != search.second.end(); ++i) {
				resultHeader.insertNode(*i);
			}
		}
		sendHeader(*soc, resultHeader);
	}
		break;
	case FSMessageType::DELETE: {
		std::string sfn = requestHeader.getFileName();

		// Try to delete local file copies
		{
			std::lock_guard<std::mutex> lk(localFileDescMutex);
			std::map<std::string, unsigned int> fileNamesMap = localFileDesc->getFileNames();
			auto searchFileName = fileNamesMap.find(sfn);
			if (searchFileName != fileNamesMap.end()) {
				// File exists, delete it and all its versions
				for (unsigned int dVersion = 1; dVersion <= searchFileName->second; ++dVersion) {
					boost::filesystem::path dir(dirName + "/" + sfn + std::to_string(dVersion));
					boost::filesystem::remove(dir);
				}
			}
			localFileDesc->erase(sfn);
		}

		if (amMaster.load() == true && fileDescriptor->fileExist(sfn) == true) {
			// If I am the master, issue deletes to replicas
			auto file = fileDescriptor->getDescriptor(sfn);
			for (auto deleteNode : file.second) {
				if (deleteNode == fds->getThisMachine()) {
					// Master deleting a node on itself, already done above
					continue;
				}
				std::array<char, BYTES_SIZE> bytesRecv;
				boost::system::error_code ec;
				FSHeader deleteHeader(FSMessageType::DELETE, sfn);
				// Make connection
				boost::asio::io_context deleteIoservice;
				tcp::resolver resolv(deleteIoservice);
				tcp::resolver::query q(deleteNode.getTheirAddress(), std::to_string(deleteNode.getTheirFSPort()));
				tcp::resolver::results_type endpoints = resolv.resolve(q);
				std::shared_ptr<tcp::socket> deleteSoc = std::make_shared<tcp::socket>(deleteIoservice);
				try {
					boost::asio::connect(*deleteSoc, endpoints);
				} catch (const boost::system::system_error & ec) {
					//return;
				}
				sendHeader(*deleteSoc, deleteHeader);

				// temp measure
				deleteSoc->read_some(boost::asio::buffer(bytesRecv), ec);

				// Wait for ack reply
				deleteSoc->read_some(boost::asio::buffer(bytesRecv), ec);
			}
			fileDescriptor->deleteFile(sfn);
		}
		FSHeader ackHeader(FSMessageType::ACK, "Finished ACK");

		sendHeader(*soc, ackHeader);

	}
		break;
	case FSMessageType::REPLICATE: {
		unsigned long fileSize = requestHeader.getFileSize();
		uint32_t numVer = requestHeader.getVersionNum();
		std::string sfn = requestHeader.getFileName();
		unsigned long sizeRead = 0;
		//std::cout << "Expected file size = " << fileSize << std::endl;
		std::string messageRead = "";
		std::ofstream f(dirName + "/" + sfn + ((numVer == 100) ? "" : std::to_string(numVer)));
		while (true) {
			std::array<char, BYTES_SIZE> bytesRecv;
			boost::system::error_code ec;
			std::size_t bytesRead = soc->read_some(boost::asio::buffer(bytesRecv), ec);
			//std::cout << "Received " << bytesRead << std::endl;
			//std::size_t bytesRead = boost::asio::read(*soc, read_buffer, boost::asio::transfer_at_least(1), ec);
			if (ec == boost::asio::error::eof) {
				std::cout << "The other end shut down" << bytesRead << std::endl;
				f.close();
				break;
			}
			for (std::size_t j = 0; j < bytesRead; ++j) {
				messageRead += bytesRecv[j];
			}
			f << messageRead;
			f.flush();
			messageRead.clear();
			//std::cout << " " << bytesRead << " " << ec.message() << std::endl;
			sizeRead += bytesRead;
			if (sizeRead >= fileSize) {
				f.close();
				break;
			}
		}

		{
			std::lock_guard<std::mutex> lk(localFileDescMutex);
			localFileDesc->insertOrUpdate(sfn, numVer);
		}
		//std::cout << "Sending ACK message" << std::endl;
		FSHeader ackHeader(FSMessageType::ACK, soc->local_endpoint().address().to_string());
		sendHeader(*soc, ackHeader);
	}
		break;
	case FSMessageType::PARTIAL_FILE_DESC: {
		std::array<char, BYTES_SIZE> bytesRecv;

		LocalFileDescriptor otherLocalFileDesc;

		boost::system::error_code ec;
		boost::asio::read(*soc, boost::asio::buffer(bytesRecv), boost::asio::transfer_all(), ec);
		{
			boost::iostreams::array_source source(bytesRecv.begin(), bytesRecv.end());
			boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
			boost::archive::binary_iarchive ia(inputStream);
			ia >> otherLocalFileDesc;
		}
		fileDescriptor->insertFromOther(otherLocalFileDesc);
	}
		break;
	case FSMessageType::REREPLICATION_REQUEST: {
		Node sourceNode = requestHeader.getNodes().front();
		std::string fileName = requestHeader.getFileName();
		std::cout << "Re-replication request received" << fileName << std::endl;

		// Loop needed to replicate many versions, up to 5
		for (unsigned int v = 1; v <= 5; ++v) {
			std::array<char, BYTES_SIZE> bytesRecv;
			boost::system::error_code ec;
			FSHeader getHeader(FSMessageType::GET, requestHeader.getFileName(), v);
			// Make connection
			boost::asio::io_context ioservice;
			tcp::resolver resolv(ioservice);
			tcp::resolver::query q(sourceNode.getTheirAddress(), std::to_string(sourceNode.getTheirFSPort()));
			tcp::resolver::results_type endpoints = resolv.resolve(q);
			std::shared_ptr<tcp::socket> getSoc = std::make_shared<tcp::socket>(ioservice);
			try {
				boost::asio::connect(*getSoc, endpoints);
			} catch (const boost::system::system_error & ec) {
				//return;
			}
			sendHeader(*getSoc, getHeader);

			// Temp measure
			getSoc->read_some(boost::asio::buffer(bytesRecv), ec);

			// reply to get response header
			sendHeader(*getSoc, getHeader);

			// Read the Get response header
			bytesRecv.fill(0);
			FSHeader getResponseHeader;
			boost::asio::read(*getSoc, boost::asio::buffer(bytesRecv), boost::asio::transfer_at_least(1), ec);
			//getSoc->read_some(boost::asio::buffer(recvBytes), ec);
			{
				try {
					boost::iostreams::array_source source(bytesRecv.begin(), bytesRecv.end());
					boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
					boost::archive::binary_iarchive ia(inputStream);
					ia >> getResponseHeader;
				} catch (boost::archive::archive_exception & e) {
					std::cout << e.what();
					throw e;
				}
			}
			if (getResponseHeader.getFSMessageType() == FSMessageType::GET_RESPONSE_BAD) {
				// Copied all the versions
				break;
			}
			// Reply to intiate the file transfer
			sendHeader(*getSoc, getResponseHeader);
			std::cout << "Trying to replicate version " << v << std::endl;

			// Read from remote
			unsigned long fileSize = getResponseHeader.getFileSize();
			unsigned long sizeRead = 0;
			std::string messageRead = "";
			std::ofstream f(dirName + "/" + fileName + std::to_string(v));

			while (true) {
				boost::system::error_code ec;
				std::size_t bytesRead = getSoc->read_some(boost::asio::buffer(bytesRecv), ec);
				if (ec == boost::asio::error::eof) {
					std::cout << "The other end shut down while getting re-replicas" << bytesRead << std::endl;
					break;
				}
				for (std::size_t j = 0; j < bytesRead; ++j) {
					messageRead += bytesRecv[j];
				}
				f << messageRead;
				f.flush();
				messageRead.clear();

				sizeRead += bytesRead;
				//std::cout << "Read " << sizeRead << std::endl;
				if (sizeRead >= fileSize) {
					break;
				}
			}
			f.close();
			FSHeader ackHeader(FSMessageType::ACK, fileName);
			sendHeader(*getSoc, ackHeader);
			{
				std::cout << "Re-replicated " << fileName << v << std::endl;
				std::lock_guard<std::mutex> lk(localFileDescMutex);
				localFileDesc->insertOrUpdate(fileName, v);
			}
		}
		// Make connection to master node to report back finished
		boost::asio::io_context ioservice;
		tcp::resolver resolv(ioservice);
		tcp::resolver::query q(masterNode.get().getTheirAddress(), std::to_string(masterNode.get().getTheirFSPort()));
		tcp::resolver::results_type endpoints = resolv.resolve(q);
		std::shared_ptr<tcp::socket> reportSoc = std::make_shared<tcp::socket>(ioservice);
		try {
			boost::asio::connect(*reportSoc, endpoints);
		} catch (const boost::system::system_error & ec) {
			//return;
		}
		FSHeader doneHeader(FSMessageType::REREPLICATION_DONE, fileName);
		doneHeader.insertNode(fds->getThisMachine());
		sendHeader(*reportSoc, doneHeader);
	}
		break;
	case FSMessageType::REREPLICATION_DONE: {
		std::vector<Node> doneNodes = requestHeader.getNodes();
		fileDescriptor->insertOrUpdate(requestHeader.getFileName(), doneNodes, 0);
	}
		break;
	default: {
	}
		break;
	}
}

void FSService::sendHeader(tcp::socket& soc, const FSHeader& fsh) {
	std::ostringstream sendBuf;
	{
		boost::archive::binary_oarchive ar(sendBuf);
		ar << fsh;
	}

	boost::asio::write(soc, boost::asio::buffer(sendBuf.str()));
	return;
}

std::string FSService::make_string(boost::asio::streambuf& streambuf) {
	return {boost::asio::buffers_begin(streambuf.data()),
		boost::asio::buffers_end(streambuf.data())};
}

/**
 * Will find n random alive nodes from the membership list
 * If the membership list is smaller than n
 * all will be selected
 */
void FSService::findNRandomAliveNodes(int n, std::vector<Node> & result) {
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	auto members = fds->getMembers();

	int i = 0;
	while (i < n) {
		auto it = members.begin();
		if (it == members.end()) {
			// The map is empty
			// Increment and not do anything
			++i;
			continue;
		}

		std::uniform_int_distribution<> dis(0, members.size() - 1);
		it = std::next(it, dis(gen));
		Node key = it->first;
		if (it->second != NodeStatus::ALIVE) {
			// The member is being suspected, do not consider this for the candidate
			members.erase(it);
			continue;
		}
		// Add the member to the list
		result.push_back(key);
		++i;
		members.erase(it);
	}
}

void FSService::startServicePrivate() {
	boost::asio::io_context ioContext;
	tcp::acceptor acceptor(ioContext, tcp::endpoint(tcp::v4(), portFS));

	while (true) {
		auto soc = std::make_shared<tcp::socket>(ioContext);
		acceptor.accept(*soc);

		// Start the processing in another thread using a thread pool
		// to avoid unresponsiveness
		boost::asio::post(*pool, [=]() {
			std::cout << "Request from: " << soc->remote_endpoint().address().to_string()
			<< ":" << soc->remote_endpoint().port() << std::endl;

			processRequest(soc);
		});
	}
}

std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher> > > FSService::getFileDescriptor() const {
	return fileDescriptor->getData();
}

LocalFileDescriptor FSService::getLocalFileDescriptor() const {

	std::lock_guard<std::mutex> lk(localFileDescMutex);
	return *localFileDesc;
}

bool FSService::amIMaster() const {
	return amMaster.load();
}

void FSService::replicate(ReplicaQueue& queue, std::vector<Node> & nodes, FSHeader& replicaHeader,
		std::vector<Node> & ackedNodes) {
	std::vector<boost::asio::io_service> replicaSocketsIOServices;
	std::vector<tcp::socket> replicaSockets;
	std::array<char, BYTES_SIZE> recvBytes;

	// Setup connections to replicating nodes
	boost::asio::io_context ioservice;
	tcp::resolver resolv(ioservice);
	for (Node n : nodes) {

		tcp::resolver::query q(n.getTheirAddress(), std::to_string(n.getTheirFSPort()));
		tcp::resolver::results_type endpoints = resolv.resolve(q);
		tcp::socket soc0(ioservice);

		try {
			boost::asio::connect(soc0, endpoints);
		} catch (const boost::system::system_error & e) {
			std::cout << "Could not connect to: " << n.getTheirAddress() << ":" << n.getTheirFSPort() << std::endl;
			//continue;
		}
		sendHeader(soc0, replicaHeader);
		// Temp measure like explained above
		boost::system::error_code ec;
		soc0.read_some(boost::asio::buffer(recvBytes), ec);

		replicaSockets.push_back(std::move(soc0));
	}

	// Send data to replicating nodes
	unsigned long fileSize = replicaHeader.getFileSize();
	unsigned long bytesSent = 0;
	//while (receiveFinished.load() == false || !queue->empty()) {
	while (true) {
		// while the transmission has not finished
		char byte;
		std::vector<char> bytes;
		while (queue.pop(byte)) {
			// while there are new bytes to send to the replica nodes
			bytes.push_back(byte);
			if (bytes.size() == BYTES_SIZE) {
				break;
			}
		}
		// Check if there is data to send
		if (!bytes.empty()) {
			//std::cout << "Sent " << bytes.size() << std::endl;
			for (auto & soc : replicaSockets) {
				boost::system::error_code ec;
				boost::asio::write(soc, boost::asio::buffer(bytes), boost::asio::transfer_exactly(bytes.size()), ec);
				if (ec) {
					//std::cout << "some node failed" << std::endl;
				}
			}
		}
		bytesSent += bytes.size();
		if (bytesSent >= fileSize) {
			break;
		}
	}

	for (std::size_t i = 0; i < replicaSockets.size(); ++i) {
		//soc.shutdown(boost::asio::ip::tcp::socket::shutdown_both, ec);
		tcp::socket & soc = replicaSockets[i];
		FSHeader recvHeader;
		boost::system::error_code ec;
		soc.read_some(boost::asio::buffer(recvBytes), ec);
		if (!ec) {
			// No error in between
			{
				boost::iostreams::array_source source(recvBytes.begin(), recvBytes.end());
				boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
				boost::archive::binary_iarchive ia(inputStream);
				ia >> recvHeader;
			}
			//std::cout << soc.remote_endpoint().port() << " completed " << recvHeader.getFileName() << std::endl;
			ackedNodes.push_back(nodes[i]);
		} else {
			// The other node failed in the replicating process
		}

		soc.close(ec);
	}
	std::cout << "Replicated" << std::endl;
	return;

}

/**
 * This function will be run by master after the file descriptor has been rebuilt
 * It will tell other nodes to replicate files from the failed nodes
 */
void FSService::coordinateReplication() {
	std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher>>> fdCopy =
			fileDescriptor->getData();
	MembersType members = fds->getMembers();
	std::cout << "ReReplication started" << std::endl;
	// First add local files to master
	{
		std::lock_guard<std::mutex> lk(localFileDescMutex);
		fileDescriptor->insertFromOther(*localFileDesc);
	}
	for (auto file : fdCopy) {
		unsigned int rereplicasNeeded = DESIRED_REPLICA_COUNT - file.second.second.size();
		if (rereplicasNeeded > 0) {
			// This file needs to be replicated
			std::vector<Node> candidates;

			getRereplicationCandidates(members, file.second.second, candidates);

			auto rereplicationSourceNodeIt = file.second.second.begin();
			for (unsigned int r = 0; r < rereplicasNeeded; ++r) {
				if (candidates.size() == 0) {
					// No more candidates left
					break;
				}
				FSHeader rereplicationRequestHeader(FSMessageType::REREPLICATION_REQUEST, file.first);

				Node candidateNode = candidates.back();
				candidates.pop_back();
				std::next(rereplicationSourceNodeIt, 1);
				Node rereplicationSourceNode = *rereplicationSourceNodeIt;
				rereplicationRequestHeader.insertNode(rereplicationSourceNode);

				// Make connection
				boost::asio::io_context ioservice;
				tcp::resolver resolv(ioservice);
				tcp::resolver::query q(candidateNode.getTheirAddress(), std::to_string(candidateNode.getTheirFSPort()));
				tcp::resolver::results_type endpoints = resolv.resolve(q);
				std::shared_ptr<tcp::socket> soc = std::make_shared<tcp::socket>(ioservice);
				try {
					boost::asio::connect(*soc, endpoints);
				} catch (const boost::system::system_error & ec) {
					//return;
				}
				//std::cout << "Sending re-replication request to " << candidateNode.getTheirAddress()
				//<< candidateNode.getTheirFSPort() << std::endl;
				sendHeader(*soc, rereplicationRequestHeader);
			}
		}
	}
}

void FSService::getRereplicationCandidates(const MembersType& members,
		const std::unordered_set<Node, NodeHasher>& existingReplicas, std::vector<Node>& result) {
	for (auto m : members) {
		auto searchInExisting = existingReplicas.find(m.first);
		if (searchInExisting == existingReplicas.end()) {
			// If the member here does not have the old replica
			result.push_back(m.first);
		}
	}

	// Check if this node was in existing replica, if not add to result
	auto wasThisNodeInExistingReplicas = existingReplicas.find(fds->getThisMachine());
	if (wasThisNodeInExistingReplicas == existingReplicas.end()) {
		result.push_back(fds->getThisMachine());
	}
	// Shuffle the results
	std::random_shuffle(result.begin(), result.end());
}
