#include <array>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstring>
#include <memory>
#include <utility>
#include <chrono>
#include <cassert>
#include <thread>
#include <algorithm>
#include <future>
#include <iomanip>

#include <boost/asio.hpp>
#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/ptime.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>
#include <boost/array.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/iostreams/device/array.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/utility.hpp>
#include <boost/thread.hpp>

#include "FSHeader.hpp"
#include "FSMessageType.hpp"
#include "Node.hpp"

using namespace boost::asio;
using namespace boost::asio::ip;

const int MIN_ARG_COUNT = 3;
const int BYTES_SIZE = 8192;
std::vector<std::pair<std::string, std::string>> machine_addr;
std::string dirName = "results";

enum class GetResult{
	GET_FAILED,
	GET_OK,
	GET_BROKEN
};

void getMachine_addr(std::string machineAddrFileName);
bool findCoordinator(tcp::socket& soc, tcp::resolver& resolv);
void sendHeader(tcp::socket& soc, const FSHeader& fsh);
bool lsService(tcp::socket& soc, const std::string sfn);
GetResult getService(tcp::socket& soc, const std::string sfn, const std::string lfn, uint32_t & numVer);
void getServiceSetup(tcp::socket& soc, const std::string sfn, const uint32_t numVer, FSHeader & getResponseHeader);
bool getVersionsService(tcp::resolver& resolv, const std::string sfn, const std::string lfn, uint32_t numVer);
bool deleteService(tcp::socket& soc, const std::string sfn);
bool putService(tcp::socket& soc, const std::string sfn, const std::string lfn);

int main(int argc, char * argv[]) {

	std::string lfn("");
	std::string sfn("");
	uint32_t numVersions = 100;
	std::string machineAddrFileName;

	bool flag = false;
	// Check args
	std::string command;
	command.assign(argv[1]);
	if (argc == 5 && command == "get") {
		lfn.assign(argv[3]);
		sfn.assign(argv[2]);
		machineAddrFileName.assign(argv[4]);
		flag = true;
	}
	if (argc == 5 && command == "put") {
		lfn.assign(argv[2]);
		sfn.assign(argv[3]);
		machineAddrFileName.assign(argv[4]);
		flag = true;
	}
	if (argc == 6 && command == "get-versions") {
		lfn.assign(argv[4]);
		sfn.assign(argv[2]);
		numVersions = atoi(argv[3]);
		machineAddrFileName.assign(argv[5]);
		flag = true;
	}
	if (argc == 4 && command == "delete") {
		sfn.assign(argv[2]);
		machineAddrFileName.assign(argv[3]);
		flag = true;
	}
	if (argc == 4 && command == "ls") {
		sfn.assign(argv[2]);
		machineAddrFileName.assign(argv[3]);
		flag = true;
	}

	if (flag == false) {
		std::cout << "Usage: " << argv[0] << std::endl;
		std::cout << "put localfilename sdfsfilename" << std::endl;
		std::cout << "get sdfsfilename localfilename" << std::endl;
		std::cout << "delete sdfsfilename" << std::endl;
		std::cout << "ls sdfsfilename" << std::endl;
		std::cout << "get-versions sdfsfilename num-versions localfilename" << std::endl;
		std::cout << " <machine addr file>" << std::endl;
		return 1;
	}

	boost::filesystem::path dir(dirName);
	// Remove all the files stored from the last run
	boost::system::error_code ecIgnored;
	boost::filesystem::remove_all(dir, ecIgnored);
	boost::filesystem::create_directory(dir);

	getMachine_addr(machineAddrFileName);

	auto startTime = std::chrono::system_clock::now();

	//find the coordinator
	while (1) {
		io_service ioservice;
		tcp::resolver resolv(ioservice);
		tcp::socket tcp_soc(ioservice);
		if (!findCoordinator(tcp_soc, resolv)) {
			// No master
			std::cout << "No server is alive right now" << std::endl;
			break;
		}

		if (command == "ls") {
			if (lsService(tcp_soc, sfn)) {
				// Service succeeded
				break;
			}
		} else if (command == "get") {
			GetResult getResult = getService(tcp_soc, sfn, lfn, numVersions);
			if (getResult == GetResult::GET_BROKEN){
				// Network or master failed, try again
			} else if(getResult == GetResult::GET_FAILED){
				std::cout << "The file does not exist in the file system" << std::endl;
				break;
			} else{
				// Get file okay
				break;
			}
		} else if (command == "put") {
			if (putService(tcp_soc, sfn, lfn)) {
				break;
			}
		} else if (command == "delete") {
			if (deleteService(tcp_soc, sfn)) {
				break;
			}
		} else if (command == "get-versions") {
			getVersionsService(resolv, sfn, lfn, numVersions);
			break;
		} else {
			break;
		}
		// Wait for four seconds for the servers rebuild
		boost::this_thread::sleep(boost::posix_time::milliseconds(4000));
	}

	auto endTime = std::chrono::system_clock::now();
	std::chrono::duration<double, std::milli> fp_ms = endTime - startTime;
	std::cout << "Operation finished in " << fp_ms.count() << " ms" << std::endl;
	return 0;
}

void getMachine_addr(std::string machineAddrFileName) {
	std::fstream addr_file;
	std::string temp;
	addr_file.open(machineAddrFileName, std::ios::in);
	// Read in the addresses
	while (!addr_file.eof()) {
		std::getline(addr_file, temp);
		if (temp[0] == '-' || temp[0] == '#') {
			// If the first char is a dash or a pound sign, then ignore this line
			// This allows for commenting in the address file
			continue;
		}

		std::vector<std::string> machineAddrParts;
		std::string delimiter = ":";
		std::string token;
		std::size_t pos = 0;
		while ((pos = temp.find(delimiter)) != std::string::npos) {
			token = temp.substr(0, pos);
			machineAddrParts.push_back(token);
			temp.erase(0, pos + delimiter.length());
		}
		machineAddrParts.push_back(temp);
		if (machineAddrParts.size() != 3) {
			// Mal-formed machine addr file
			continue;
		}

		std::string addr = machineAddrParts[0];
		std::string portFD = machineAddrParts[1];
		std::string portFS = machineAddrParts[2];
		machine_addr.push_back(std::make_pair(addr, portFS));
	}
	addr_file.close();

}

bool findCoordinator(tcp::socket& soc, tcp::resolver& resolv) {
	std::vector<tcp::endpoint> availableEndpoints;
	struct EndpointCompare {
		bool operator()(tcp::endpoint i, tcp::endpoint j) {
			if (i.address() == j.address()) {
				return i.port() < j.port();
			}
			return i.address() < j.address();
		}
	} EndpointCompare;
	for (auto addr : machine_addr) {
		tcp::resolver::query q(addr.first, addr.second);
		//tcp::resolver::results_type endpoints = resolv.resolve(q);
		tcp::resolver::iterator iter = resolv.resolve(q);
		tcp::endpoint endpoint = iter->endpoint();
		availableEndpoints.push_back(endpoint);

	}
	// Sort the available servers from smaller ip to bigger ip
	std::sort(availableEndpoints.begin(), availableEndpoints.end(), EndpointCompare);
	for (auto e : availableEndpoints) {
		//std::cout << e.address() << std::endl;
		try {
			soc.connect(e);
			//boost::asio::connect(soc, e);
		} catch (const boost::system::system_error & ec) {
			//std::cout << "Could not connect to: " << e.address() << ":" << e.port() << std::endl;
			continue;
		}
		std::cout << "Using " << e.address() << ":" << e.port() << " as master" << std::endl;
		return true;
	}
	return false;
}

void sendHeader(tcp::socket& soc, const FSHeader& fsh) {
	std::ostringstream sendBuf;
	{
		boost::archive::binary_oarchive ar(sendBuf);
		ar << fsh;
	}

	write(soc, buffer(sendBuf.str()));
	return;
}

bool lsService(tcp::socket& soc, const std::string sfn) {
	FSHeader requestHeader(FSMessageType::LS, sfn);
	sendHeader(soc, requestHeader);
	FSHeader recvHeader;

	std::array<char, 8192> bytes;
	boost::system::error_code ec;
	// Temp measure reply
	soc.read_some(buffer(bytes), ec);
	// Send something to receive LS
	sendHeader(soc, requestHeader);
	soc.read_some(buffer(bytes), ec);
	{
		boost::iostreams::array_source source(bytes.begin(), bytes.end());
		boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
		boost::archive::binary_iarchive ia(inputStream);
		ia >> recvHeader;
	}
	if (ec) {
		return false;
	}
	assert(recvHeader.getFSMessageType() == FSMessageType::LS);

	recvHeader.getLsResult();

	return true;
}

/**
 * Will get a file to results directory,
 * and replace the version number passed in with the grabbed version (useful for get-versions)
 */
GetResult getService(tcp::socket& soc, const std::string sfn, const std::string lfn, uint32_t & numVer) {
	FSHeader getResponseHeader;
	tcp::socket * actualSocket = &soc;
	getServiceSetup(soc, sfn, numVer, getResponseHeader);

	if (getResponseHeader.getFSMessageType() == FSMessageType::GET_RESPONSE_BAD) {
		// The file get failed
		return GetResult::GET_FAILED;
	}
	boost::asio::io_context ioservice;
	tcp::socket redirectedSoc(ioservice);
	if (getResponseHeader.getFSMessageType() == FSMessageType::GET_RESPONSE_REDIRECT) {
		Node redirectedNode = getResponseHeader.getNodes().front();
		tcp::resolver resolv(ioservice);
		tcp::resolver::query q(redirectedNode.getTheirAddress(), std::to_string(redirectedNode.getTheirFSPort()));
		tcp::resolver::results_type endpoints = resolv.resolve(q);
		try {
			boost::asio::connect(redirectedSoc, endpoints);
		} catch (const boost::system::system_error & ec) {
			return GetResult::GET_BROKEN;
		}
		getServiceSetup(redirectedSoc, sfn, numVer, getResponseHeader);
		if (getResponseHeader.getFSMessageType() == FSMessageType::GET_RESPONSE_BAD) {
			// The file get failed
			return GetResult::GET_FAILED;
		}
		actualSocket = &redirectedSoc;
	}
	// Set local version number
	numVer = getResponseHeader.getVersionNum();

	// Reply to initiate file transfer
	sendHeader(*actualSocket, getResponseHeader);
	std::array<char, BYTES_SIZE> bytes;
	unsigned long fileSize = getResponseHeader.getFileSize();
	unsigned long sizeRead = 0;
	std::string messageRead = "";
	std::ofstream f(dirName + "/" + lfn + ((numVer == 100) ? "" : std::to_string(numVer)));

	while (true) {
		boost::system::error_code ec;
		std::size_t bytesRead = actualSocket->read_some(boost::asio::buffer(bytes), ec);
		if (ec == boost::asio::error::eof) {
			std::cout << "The other end shut down while getting files to client" << bytesRead << std::endl;
			break;
		}
		for (std::size_t j = 0; j < bytesRead; ++j) {
			messageRead += bytes[j];
		}
		f << messageRead;
		f.flush();
		messageRead.clear();

		sizeRead += bytesRead;
		if (sizeRead >= fileSize) {
			break;
		}
	}
	f.close();
	FSHeader ackHeader(FSMessageType::ACK, sfn);
	sendHeader(*actualSocket, ackHeader);

	return GetResult::GET_OK;
}

void getServiceSetup(tcp::socket& soc, const std::string sfn, const uint32_t numVer, FSHeader & getResponseHeader) {
	FSHeader requestHeader(FSMessageType::GET, sfn, numVer);

	sendHeader(soc, requestHeader);

	std::array<char, BYTES_SIZE> bytes;
	// The temporary measure described in FSSerivce.cpp
	soc.read_some(buffer(bytes));

	// Read in the Get Response
	bytes.fill(0);
	//reply to get response header
	sendHeader(soc, requestHeader);
	//soc.write_some(buffer(bytes));
	boost::system::error_code ec;
	soc.read_some(buffer(bytes), ec);
	{
		boost::iostreams::array_source source(bytes.begin(), bytes.end());
		boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
		boost::archive::binary_iarchive ia(inputStream);
		ia >> getResponseHeader;
	}
}

bool getVersionsService(tcp::resolver& resolv, const std::string sfn, const std::string lfn, uint32_t numVer) {
	unsigned int currentVersion = 100;
	while (numVer > 0) {
		io_service ioservice;
		tcp::resolver resolv(ioservice);
		tcp::socket tcp_soc(ioservice);
		if (!findCoordinator(tcp_soc, resolv)) {
			std::cout << "Operation could not be completed" << std::endl;
			return false;
		}
		GetResult getResult = getService(tcp_soc, sfn, lfn, currentVersion);
		if (getResult == GetResult::GET_OK) {
			numVer--;
			--currentVersion;
			if (currentVersion == 0) {
				// Reached end
				return true;
			}
			continue;
		}else if (getResult == GetResult::GET_FAILED){
			std::cout << "The file does not exist in the file system" << std::endl;
			return false;
		}else{
			// Network or master failed, try again
		}
		// Wait for four seconds for the servers to rebuild
		boost::this_thread::sleep(boost::posix_time::milliseconds(4000));
	}
	return true;
}

bool deleteService(tcp::socket& soc, const std::string sfn) {
	FSHeader requestHeader(FSMessageType::DELETE, sfn);
	sendHeader(soc, requestHeader);
	FSHeader recvHeader;

	std::array<char, 8192> bytes;
	boost::system::error_code ec;
	// Temp measure
	soc.read_some(buffer(bytes), ec);
	// Read the ack header
	soc.read_some(buffer(bytes), ec);
	{
		boost::iostreams::array_source source(bytes.begin(), bytes.end());
		boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
		boost::archive::binary_iarchive ia(inputStream);
		ia >> recvHeader;
	}
	if (ec) {
		return false;
	}

	assert(recvHeader.getFSMessageType() == FSMessageType::ACK);

	return true;
}

bool putService(tcp::socket& soc, const std::string sfn, const std::string lfn) {
	std::ifstream f(lfn, std::ios::in | std::ios::binary | std::ios::ate);

	long size;
	std::array<char, BYTES_SIZE> bytes;
	//char bytes[8192];
	if (f.is_open()) {
		//f.seekg(0, f.end)
		size = f.tellg();
		FSHeader requestHeader(FSMessageType::PUT, sfn);
		requestHeader.setFileSize(size);
		sendHeader(soc, requestHeader);

		// The temporary measure described in FSSerivce.cpp
		soc.read_some(buffer(bytes));

		f.seekg(0);
		while (size > 0) {
			int readSize = ((size > BYTES_SIZE) ? BYTES_SIZE : size);
			size = size - readSize;
			//std::cout << readSize << " " << size << std::endl;
			f.read(bytes.data(), readSize);
			boost::system::error_code ec;
			write(soc, buffer(bytes), boost::asio::transfer_exactly(readSize), ec);
			if (ec) {
				return false;
			}
		}
		f.close();
	}
	//soc.shutdown(boost::asio::socket_base::shutdown_send);

	//TODO: we may need another socket (server) to receive the ack, since the time of replica is unpredictable;

	//or we set the option of socket to bypass this issue 
	/*
	 struct timeval tv;
	 tv.tv_sec  = 5;
	 tv.tv_usec = 0;
	 setsockopt(tcpsocket->native_handle(), SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	 */
	// or
	/*
	 boost::asio::socket_base::keep_alive option(true);
	 soc.set_option(option);
	 */

	FSHeader recvHeader;

	std::array<char, 8192> recvBytes;

	boost::system::error_code ec;
	soc.read_some(buffer(recvBytes), ec);
	{
		boost::iostreams::array_source source(recvBytes.begin(), recvBytes.end());
		boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
		boost::archive::binary_iarchive ia(inputStream);
		ia >> recvHeader;
	}
	std::cout << recvHeader.getFileName() << std::endl;
	if (ec && (ec != boost::asio::error::eof)) {
		return false;
		//break; // Connection closed cleanly by peer.
	}

	assert(recvHeader.getFSMessageType() == FSMessageType::ACK);

	return true;
}

