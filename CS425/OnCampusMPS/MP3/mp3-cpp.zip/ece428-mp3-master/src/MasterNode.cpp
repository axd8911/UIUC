#include "MasterNode.hpp"

MasterNode::MasterNode() {
}

MasterNode::~MasterNode() {
}

bool MasterNode::update(Node n) {
	std::lock_guard<std::mutex> lk(m);
	bool masterNodeChanged = !(n == this->node);
	this->node = n;
	return masterNodeChanged;
}

Node MasterNode::get() {
	std::lock_guard<std::mutex> lk(m);
	return this->node;
}
