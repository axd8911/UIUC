#include "FDService.hpp"
#include "Node.hpp"
#include "MessageType.hpp"
#include "BlockingUDPTimedClient.hpp"
#include "NodeUpdateList.hpp"

#include <memory>
#include <thread>
#include <iostream>
#include <sstream>
#include <utility>
#include <thread>
#include <algorithm>
#include <future>
#include <iomanip>

#include <boost/date_time/posix_time/ptime.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>
#include <boost/array.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/iostreams/device/array.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/serialization/utility.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread.hpp>

using boost::asio::ip::udp;

FDService::FDService(unsigned short port, unsigned short portFS,
		std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines, bool logVerbose,
		bool falsePositiveTest,
		std::function<
				void(std::vector<Node>, std::vector<Node> members, Node thisMachine, std::vector<Node> failedNodes)> reelectMasterCallback) {
	haveJoined.store(false);
	haveLeft.store(false);
	pingSent.store(0);
	this->machines = machines;
	this->logVerbose = logVerbose;
	this->falsePositiveTest = falsePositiveTest;
	this->reelectMasterCallback = reelectMasterCallback;
	this->port = port;
	this->portFS = portFS;
	senderPool = std::make_shared<boost::asio::thread_pool>(PING_NODES_COUNT);
	std::string logFileName = "log" + boost::lexical_cast<std::string>(port) + ".txt";
	f_log.open(logFileName, std::ofstream::out | std::ofstream::app);
	setupService();
	//startService(port, portFS);
}

FDService::~FDService() {
	f_log.close();
}

bool FDService::setupService() {
	if (machines->size() == 0) {
		// If there aren't any other machines known, return
		return false;
	}
	// Get this machine's own address according to the subnet
	boost::asio::io_service ownIPIOService;
	udp::resolver resolver(ownIPIOService);
	udp::resolver::query q(machines->front().first, machines->front().second);
	udp::endpoint receiver_endpoint = *resolver.resolve(q);

	udp::socket socket(ownIPIOService);
	socket.open(udp::v4());
	socket.connect(receiver_endpoint);
	myAddr = socket.local_endpoint().address().to_string();
	std::cout << "This machine's IP in the subnet: " << myAddr << std::endl;
	// Initiate join requests
	unsigned long timeNow = std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::system_clock::now().time_since_epoch()).count();
	thisMachine = std::make_shared<Node>(myAddr, port, portFS, timeNow, 0);
	return true;
}

bool FDService::startService() {
	// Start listener service
	boost::thread listenerThread([=]()
	{
		pingListener(port);
	});

	Header joinHeader(MessageType::JOIN_REQ);
	joinHeader.insert(*thisMachine, NodeStatus::NEW);

	// For each machines, try to join
	std::for_each(machines->begin(), machines->end(), [&](std::pair<std::string, std::string> &m)
	{
		Node joinNode(m.first, boost::lexical_cast<unsigned short>(m.second), 0, 0, 0);
		if(haveJoined.load() == false) {
			//writeLocalLog('j','t', joinNode);

		}
		bool res = waitForSingleAck(haveJoined, joinHeader, joinNode, 100);
		if(res == true) {
			//writeLocalLog('j','h', joinNode);
		}
	});

	// Start failure detector service
	boost::thread senderThread([=]()
	{
		pingSender();
	});

	// Clean up and return
	senderThread.detach();
	listenerThread.detach();
	return true;
}

bool FDService::waitForSingleAck(std::atomic<bool> & listeningFlag, const Header& header, const Node & targetNode,
		unsigned int timeOutMs) {
	if (listeningFlag.load() == true) {
		// Already joined from a node
		return false;
	}
	try {
		sendHeader(targetNode, header);
	} catch (boost::system::system_error& e) {
		// Error sending, move on to next machine
		return false;
	}

	auto waitStart = std::chrono::system_clock::now();
	while (listeningFlag.load() == false) {
		auto waitEnd = std::chrono::system_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(waitEnd - waitStart).count();
		if (duration > timeOutMs) {
			// Still no response after timeout, try next machine as introduction point
			return false;
		}
	}
	return true;
}

void FDService::pingListener(unsigned short port) {
	boost::asio::io_service ioservice;
	BlockingUDPTimedClient c(udp::endpoint(udp::v4(), port));

	while (true) {
		if (haveLeft.load() == true) {
			// Ready to leave
			return;
		}
		boost::array<char, 8192> recvBuf;
		udp::endpoint remote_endpoint;

		boost::system::error_code ec;
		c.receive(recvBuf, boost::posix_time::milliseconds(200), ec);
		// Check time outs
		checkTimeOuts(boost::optional<Node>());
		if (ec) {
			continue;
		}

		// Process receive header
		Header recvHeader;
		{
			boost::iostreams::array_source source(recvBuf.begin(), recvBuf.end());
			boost::iostreams::stream<boost::iostreams::array_source> inputStream(source);
			boost::archive::binary_iarchive ia(inputStream);
			ia >> recvHeader;
		}
		handleReceivedHeader(recvHeader);

	}
}

void FDService::handleReceivedHeader(Header & header) {
	MessageType messageType = header.getMessageType();
	switch (messageType) {
	case MessageType::ACK: {
		Node ackReceivedNode = header.getFirst();
		writeEventLog('a', ackReceivedNode);
		checkTimeOuts(boost::optional<Node>(ackReceivedNode));
	}
		break;
	case MessageType::LEAVE:
		//writeEventLog('l', header.getFirst());
		processReceivedHeader(header);
		break;
	case MessageType::LEAVE_ACK:
		haveLeft.store(true);
		break;
	case MessageType::JOIN_ACK:
		haveJoined.store(true);
		processReceivedHeader(header);
		break;
	case MessageType::JOIN_REQ:
		processReceivedHeader(header);
		break;
	case MessageType::PING:
		writeEventLog('p', header.getFirst());
		processReceivedHeader(header);
		break;
	}
}

void FDService::processReceivedHeader(Header& header) {
	for (auto it = header.begin(); it != header.end(); ++it) {
		Node n = it->first;
		if (thisMachine->weakEquals(n)) {
			// The node is myself
			if (it->second == NodeStatus::SUSPECTED) {
				// I am being suspected
				// Correct fake news
				thisMachine->incVInc();
				dissemQueue.push(std::make_pair(*thisMachine, NodeStatus::ALIVE));
			}
			continue;
		}
		switch (it->second) {
		case NodeStatus::NEW: {
			// If this is a new node
			writeEventLog('j', n);
			Header returnHeader(MessageType::JOIN_ACK);
			returnHeader.copyFromMembershipList(members);
			returnHeader.insert(*thisMachine, NodeStatus::ALIVE);
			if (members.insert(n, NodeStatus::ALIVE)) {
				std::vector<Node> newNodes;
				newNodes.push_back(n);
				reelectMaster(newNodes, std::vector<Node>());
				dissemQueue.push(std::make_pair(n, NodeStatus::ALIVE));
			}

			boost::asio::post(*senderPool, [=]()
			{
				sendHeader(n, returnHeader);
			});
		}
			break;
		case NodeStatus::ALIVE: {
			if (members.insert(n, it->second)) {
				std::cout << n.getTheirPort() << " is alive" << std::endl;
				writeEventLog('u', n);
				// If this is an up to date message
				dissemQueue.push(std::make_pair(n, NodeStatus::ALIVE));
				std::vector<Node> newNodes;
				newNodes.push_back(n);
				reelectMaster(newNodes, std::vector<Node>());
			}
		}
			break;
		case NodeStatus::SUSPECTED: {
			// Someone is suspected
			if (members.modifyNodeStatus(n, NodeStatus::SUSPECTED)) {
				writeEventLog('s', n);
			}
			if (members.isIn(n)) {
				// Prevent circulating suspicion messages.
				dissemQueue.push(std::make_pair(n, NodeStatus::SUSPECTED));
			}
		}
			break;
		case NodeStatus::FAILED: {
			// Some one has failed
			if (members.erase(n)) {
				writeEventLog('f', n);
				dissemQueue.push(std::make_pair(n, NodeStatus::FAILED));

				std::vector<Node> failedNodes;
				failedNodes.push_back(n);
				reelectMaster(std::vector<Node>(), failedNodes);
			}
		}
			break;
		case NodeStatus::LEAVE: {
			// If a node leave voluntarily
			Header returnHeader(MessageType::LEAVE_ACK);
			boost::asio::post(*senderPool, [=]()
			{
				sendHeader(n, returnHeader);
			});

			if (members.erase(it->first)) {
				std::cout << "Heard " << n.getTheirPort() << " left" << std::endl;
				writeEventLog('l', n);
				dissemQueue.push(std::make_pair(n, NodeStatus::LEAVE));

				std::vector<Node> failedNodes;
				failedNodes.push_back(n);
				reelectMaster(std::vector<Node>(), failedNodes);
			}
		}
			break;
		case NodeStatus::PONG: {
			// This is node to send back ack to
			Header ackHeader(MessageType::ACK);
			ackHeader.insert(*thisMachine, NodeStatus::ALIVE);
			// Try to insert this machine as a member as well
			if (!members.isIn(n)) {
				members.insert(n, NodeStatus::ALIVE);
				std::vector<Node> newNodes;
				newNodes.push_back(n);
				reelectMaster(newNodes, std::vector<Node>());
			}
			boost::asio::post(*senderPool, [=]()
			{
				sendHeader(n, ackHeader);
			});
		}
			break;
		default:
			break;
		}
	}
}

// Send the header to a node
void FDService::sendHeader(const Node& n, const Header& h) {
	boost::asio::io_service sendIOService;
	udp::resolver resolver(sendIOService);

	udp::socket socket(sendIOService);
	socket.open(udp::v4());

	udp::resolver::query q(n.getTheirAddress(), boost::lexical_cast<std::string>(n.getTheirPort()));
	udp::endpoint receiver_endpoint = *resolver.resolve(q);

	std::ostringstream sendBuf;
	{
		boost::archive::binary_oarchive ar(sendBuf);
		ar << h;
	}
	try {
		socket.send_to(boost::asio::buffer(sendBuf.str()), receiver_endpoint);
	} catch (boost::system::system_error& e) {
	}
}

void FDService::pingSender() {
	NodeUpdateList updates;
	// Infinite loop, only return when this node decides to leave
	while (true) {
		if (haveLeft.load() == true) {
			// Ready to leave
			return;
		}
		// Get the new updates from listener
		std::pair<Node, NodeStatus> updateMessage;
		std::vector<Node> failedNodes;
		std::vector<Node> newNodes;
		while (dissemQueue.pop(updateMessage)) {
			updates.insertUpdate(updateMessage.first, updateMessage.second);
			if (updateMessage.second == NodeStatus::FAILED) {
				// A node has failed, notify FSService
				failedNodes.push_back(updateMessage.first);
			}
			if (updateMessage.second == NodeStatus::ALIVE && !(updateMessage.first == *thisMachine)) {
				// A node has joined
				newNodes.push_back(updateMessage.first);
			}
		}
		// If there are new nodes, reelect master
		if (newNodes.size() > 0 || failedNodes.size() > 0) {
			reelectMaster(newNodes, failedNodes);
		}

		for (int i = 0; i < std::min((int) members.size(), PING_NODES_COUNT); ++i) {
			boost::optional<Node> n = getNextContact();
			if (!n.has_value()) {
				break;
			}
			if (!members.isIn(n.get())) {
				// This node is already gone in the real time membership list
				// Don't send to it
				continue;
			}
			Header pingHeader(MessageType::PING);
			pingHeader.insert(*thisMachine, NodeStatus::PONG);
			// Piggy back information
			updates.prepareUpdateHeader(pingHeader);
			boost::asio::post(*senderPool, [=]()
			{
				sendHeader(n.get(), pingHeader);
				++pingSent;
				writeLocalLog('p','t',n.get());
			});
			// Add node to ack expectations list
			ackExpectations.push(std::make_pair(n.get(), std::chrono::steady_clock::now()));
		}
		// Wait for next round
		boost::this_thread::sleep(boost::posix_time::milliseconds(PING_WAIT_MS));
	}
}

boost::optional<Node> FDService::getNextContact() {
	boost::optional<Node> res;
	if (contacts.empty()) {
		// Get it re-shuffled
		members.copyToNodesVector(contacts);
		if (contacts.empty()) {
			// Still empty, this node doesn't have members
			return res;
		}
		std::random_shuffle(contacts.begin(), contacts.end());
	}
	Node n = contacts.back();
	contacts.pop_back();
	res = n;
	return res;
}

void FDService::checkTimeOuts(const boost::optional<Node> & ackReceivedNode) {
	auto nodesTimeOutStatus = ackExpectations.processTimeOuts(ackReceivedNode);
	for (auto p : nodesTimeOutStatus) {
		if (!members.isIn(p.first)) {
			// This node is already gone (maybe the leave happened right before)
			// Ignore this fail
			continue;
		}
		// p.second dictates whether to upgrade node status or down grade it.
		NodeStatus newStatus = members.updateNodeStatus(p.first, p.second);
		if (newStatus == NodeStatus::SUSPECTED) {
			writeEventLog('s', p.first);
		} else if (newStatus == NodeStatus::FAILED) {
			// If this is a false positive test, print false positive rate, since this failure and then return
			// Return by using the leave process but without sending leave commands
			if (falsePositiveTest) {
				unsigned int pingsSent = pingSent.load();
				std::cout << "First failure detected after " << pingsSent << " pings." << std::endl;
				std::cout << "False positive rate is " << 1.0 / pingsSent << std::endl;
			}
			writeEventLog('f', p.first);
		} else if (newStatus == NodeStatus::ALIVE) {
			writeEventLog('u', p.first);
		}
		if (newStatus != NodeStatus::EMPTY) {
			dissemQueue.push(std::make_pair(p.first, newStatus));
		}
	}
}

void FDService::writeLocalLog(char type, char status, const Node &node) {
	std::lock_guard<std::mutex> lock(logLock);
	std::string timeFormatted = boost::posix_time::to_simple_string(boost::posix_time::second_clock::local_time());
	std::stringstream logStream;
	logStream << timeFormatted << " ";

	if (status == 't' && !logVerbose) {
		// Not verbose
		return;
	}

	switch (type) {
	case 'j': {
		logStream << ((status == 't') ? "trying to join from" : "joined from ") << node << std::endl;
		break;
	}
	case 'l': {
		logStream << ((status == 't') ? "trying to leave from" : "left from ") << node << std::endl;

		break;
	}
	case 'f': {
		logStream << node << " failed" << std::endl;
		break;
	}
	case 'p': {
		if (!logVerbose) {
			return;
		}
		logStream << "pinged " << node << std::endl;
		break;
	}
	default:
		break;

	}
	f_log << logStream.str();
	std::flush(f_log);
}

void FDService::writeEventLog(char type, const Node &node) {
	std::lock_guard<std::mutex> lock(logLock);
	std::string timeFormatted = boost::posix_time::to_simple_string(boost::posix_time::second_clock::local_time());
	std::stringstream logStream;
	logStream << timeFormatted << " " << node;

	switch (type) {
	case 'j': {
		logStream << " joined\n";
		break;
	}
	case 'l': {
		logStream << " left\n";
		break;
	}
	case 'u': {
		logStream << " is up\n";
		break;
	}
	case 's': {
		logStream << " is suspected\n";
		break;
	}
	case 'f': {
		logStream << " failed\n";
		break;
	}
	case 'p': {
		if (!logVerbose) {
			return;
		}
		logStream << " pinged me\n";
		break;
	}
	case 'a': {
		if (!logVerbose) {
			return;
		}
		logStream << " ping ack received\n";
		break;
	}
	default:
		break;
	}
	f_log << logStream.str();
	std::flush(f_log);
}

std::unordered_map<Node, NodeStatus, NodeHasher> FDService::getMembers() {
	std::unordered_map<Node, NodeStatus, NodeHasher> copyM;
	members.copyToAnotherMap(copyM);
	return copyM;
}

void FDService::leave() {
	std::unordered_map<Node, NodeStatus, NodeHasher> membersCopy = getMembers();
	Header leaveHeader(MessageType::LEAVE);
	leaveHeader.insert(*thisMachine, NodeStatus::LEAVE);
	std::for_each(membersCopy.begin(), membersCopy.end(), [&](std::pair<const Node, NodeStatus> &m)
	{
		if(haveLeft.load() == false) {
			//writeLocalLog('l','t', m.first);
		}
		bool res = waitForSingleAck(haveLeft, leaveHeader, m.first, 100);
		if(res == true) {
			//writeLocalLog('l','h', m.first);
		}
	});
	haveLeft.store(true);
	senderPool->join();
}

Node FDService::getThisMachine() {
	return *thisMachine;
}

void FDService::reelectMaster(std::vector<Node> newNodes, std::vector<Node> failedNodes) {
	std::unordered_map<Node, NodeStatus, NodeHasher> members = getMembers();
	std::vector<Node> existingMembers;
	for (auto n : members) {
		existingMembers.push_back(n.first);
	}
	reelectMasterCallback(newNodes, existingMembers, getThisMachine(), failedNodes);
}
