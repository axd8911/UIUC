#include "FileDescriptor.hpp"

#include <iostream>

FileDescriptor::FileDescriptor() {
}

FileDescriptor::~FileDescriptor() {
}

bool FileDescriptor::insertOrUpdate(std::string fileName, std::vector<Node>& nodes, unsigned int version) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	if (search != descriptor.end()) {
		auto & nodeSet = search->second.second;
		search->second.first = std::max(version, search->second.first);
		for (auto n : nodes) {
			// Set can avoid duplicates
			nodeSet.insert(n);
		}
		return false;
	}

	std::unordered_set<Node, NodeHasher> nodeSet;
	for (auto n : nodes) {
		nodeSet.insert(n);
	}
	descriptor.insert(std::make_pair(fileName, std::make_pair(version, nodeSet)));
	return true;
}

bool FileDescriptor::deleteFile(std::string fileName) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	if (search == descriptor.end()) {
		return false;
	}

	descriptor.erase(fileName);
	return true;
}

bool FileDescriptor::update(std::string fileName) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	if (search == descriptor.end()) {
		return false;
	}

	search->second.first++;

	return true;
}

bool FileDescriptor::change(std::string fileName, Node& node) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	if (search == descriptor.end()) {
		return false;
	}

	search->second.second.insert(node);

	return true;
}

bool FileDescriptor::fail(Node& node) {
	std::lock_guard<std::mutex> lk(m);
	for(auto & file : descriptor){
		file.second.second.erase(node);
	}

	return true;
}

bool FileDescriptor::fileExist(std::string fileName) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	return search != descriptor.end();
}

/**
 * Return the descriptor of a given file
 * If the file does not exist, return version of 0, and an empty node list
 */
std::pair<uint32_t, std::unordered_set<Node, NodeHasher>> FileDescriptor::getDescriptor(std::string fileName) {
	std::lock_guard<std::mutex> lk(m);
	auto search = descriptor.find(fileName);
	if (search == descriptor.end()) {
		return std::make_pair(0, std::unordered_set<Node, NodeHasher>());
	}
	return search->second;

}

void FileDescriptor::insertFromOther(LocalFileDescriptor &otherLocal) {
	Node n = otherLocal.getNode();
	std::map<std::string, unsigned int> otherFileNames = otherLocal.getFileNames();
	std::vector<Node> nodes;
	nodes.push_back(n);
	for (auto fileName : otherFileNames) {
		insertOrUpdate(fileName.first, nodes, fileName.second);
	}
}

std::unordered_map<std::string, std::pair<uint32_t, std::unordered_set<Node, NodeHasher> > > FileDescriptor::getData() const {
	std::lock_guard<std::mutex> lk(m);
	return descriptor;
}
