#!/bin/sh
mkdir -p filesToSend
wget -O filesToSend/file0 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day6_1.gz
wget -O filesToSend/file1 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day7_1.gz
wget -O filesToSend/file2 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day8_1.gz
wget -O filesToSend/file3 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day9_1.gz
wget -O filesToSend/file4 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day10_1.gz
wget -O filesToSend/file5 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day11_1.gz
wget -O filesToSend/file6 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day12_1.gz
wget -O filesToSend/file7 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day13_1.gz
wget -O filesToSend/file8 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day14_1.gz
wget -O filesToSend/file9 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day15_1.gz
wget -O filesToSend/file10 ftp://ita.ee.lbl.gov/traces/WorldCup/wc_day16_1.gz

