#!/bin/sh

./server $((8009 + $1)) machine_addr.txt $((8100 + $1))

