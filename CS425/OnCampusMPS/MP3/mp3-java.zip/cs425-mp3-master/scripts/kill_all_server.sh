#!/bin/bash

ssh -i ~/dlvm fangwei2@fa18-cs425-g17-01.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-02.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-03.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-04.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-05.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-06.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-07.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-08.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-09.cs.illinois.edu pkill java
ssh -i ~/dlvm fangwei2@fa18-cs425-g17-10.cs.illinois.edu pkill java
