import cs425.mp3.Util;

public class test {

    public static void main(String... args) {
        System.err.println("Start test");
        Util.noExceptionSleep(500);
        System.err.println("End test");
    }

}
