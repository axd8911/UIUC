# cs425-mp2

## START THE NODE

$python3 server.py

## COMMAND

join: send request to join

leave: leave the group voluntary

lm: list membership

vm: show this vm's address

exit: exit from the group

## .LOG

mp2.log
Use //$python3 client.py filepath pattern// to test the .log file