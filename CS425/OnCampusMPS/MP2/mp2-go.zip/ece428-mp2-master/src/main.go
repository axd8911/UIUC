package main

import (
	"bufio"
	"failure"
	"fmt"
	"grep_server"
	"log"
	"os"
)

func main() {
	println("Starting server")
	log.SetFlags(log.Lshortfile)

	failure.Initialize()
	// go failure.SendPingTest([]string{"fa18-cs425-g27-07.cs.illinois.edu"})

	go func() {
		fmt.Print("Type 'leave' to shut down server\n")
		for {
			reader := bufio.NewReader(os.Stdin)
			text, _ := reader.ReadString('\n')
			if text == "leave\n" {
				fmt.Println("Leaving group")
				failure.LeaveGroup()
			}
		}
	}()

	grep_server.OpenGrepPort()

	// Keep the program running so it doesn't close the port
	for {
	}
}
