# ECE 428 - Distributed Systems

## How to Use

* Ansible method - run `clone_git_repos`, then `run_servers`
* Regular method
    * SSH into each machine
    * `cd` into `~/mp2/src`
    * `make`
    * `./ece428`

## Initial Design
* Startup
    * Server 1 is introducer node
    * Any node joining connects to server 1 and follows join protocol
* Join protocol
    * Copy membership list from introducer
    * New node adds itself to its membership list
        * Put in correct spot
        * Implement with either linked list or array
* Send pings
    * Include changed entries from membership list in ping
    * Set changed entries in your own membership list to not changed
* Receiving a ping
    * Send ACK back to ping source
    * Update membership list
        * If received timestamp greater than current, overwrite whole entry, mark as changed
        * If received is failed and current is not failed, set failed, mark as changed
        * Otherwise do nothing
* Expecting ACK
    * If received, do nothing
    * If no ACK, then set membership list entry to failed, and mark as changed
* Leaving voluntarily
    * TALK ABOUT THIS
* Other
    * Potentially add failure detection code to the grep code, so we can run one process instead of 2

## Ansible
See mp1 repo to setup Ansible

To run one of the playbooks, run `ansible-playbook /*PLAYBOOK NAME*/ -i inventory.ini -u /*USERNAME*/` from the `ansible/` directory.
Username should either be `cguldne2` or `jzabins2`. Then enter your password.

* `clone_git_repos.yml` - This playbook downloads the git repo onto each machine.
* `run_servers.yml` - Runs the `server.go` file on the VMs for 5 minutes.
* `kill_servers.yml` - Kills any processes running under the name *ece428*.
* `destroy_logs.yml` - Removes any logs in the top level directory, or in `mp2/src/`.
