// STL
#include <iostream>
#include <memory>
#include <vector>
#include <string>
#include <fstream>
#include <utility>

// Boost
#include <boost/lexical_cast.hpp>

#include "../include/FDService.hpp"
#include "../include/Node.hpp"
#include "../include/MessageType.hpp"
#include "../include/BlockingUDPTimedClient.hpp"

using Machines = std::vector<std::pair<std::string, std::string>>;

using boost::asio::ip::udp;

int main(int argc, char **argv){
    if(argc < 3) {
        std::cout << "Usage: " << argv[0] << " <port number>" << " <address file>" << std::endl;
        return 1;
    }
    // Assign port
    unsigned short portNum = boost::lexical_cast<unsigned short>(argv[1]);

    // Read in the other server addresses
    std::string addrFileName;
    addrFileName.assign(argv[2]);
    std::shared_ptr<Machines> machine_addr = std::make_shared<Machines>();
    std::fstream addr_file;
    std::string temp;
    addr_file.open(addrFileName, std::ios::in);

    while(!addr_file.eof( ))
    {
        std::getline(addr_file, temp);
        if (temp[0] == '-' || temp[0] == '#'){
            // If the first char is a dash or a pound sign, then ignore this line
            // This allows for commenting in the address file
            continue;
        }
        int delim = temp.find(":");
        if (delim < 0)
        {
            // If the line read before did not have a colon in it, it is not an address
            continue;
        }
        std::string addr = temp.substr(0, delim);
        std::string port = temp.substr(delim + 1);
        machine_addr->push_back(std::make_pair(addr, port));
    }
    addr_file.close();

    boost::asio::io_service ownIPIOService;
    udp::resolver resolver(ownIPIOService);
    udp::resolver::query q(machine_addr->front().first, machine_addr->front().second);
    udp::endpoint receiver_endpoint = *resolver.resolve(q);

    udp::socket socket(ownIPIOService);
    socket.open(udp::v4());
    socket.connect(receiver_endpoint);
    std::string myAddr;
    myAddr = socket.local_endpoint().address().to_string();
    std::cout << "This machine's IP in the subnet: " << myAddr << std::endl;

    unsigned long timeNow = std::chrono::duration_cast<std::chrono::milliseconds>
                            (std::chrono::system_clock::now().time_since_epoch()).count();
    std::shared_ptr<Node> thisMachine;
    thisMachine = std::make_shared<Node>(myAddr, portNum, timeNow, 0);

    Header leaveHeader(MessageType::LEAVE);
    leaveHeader.insert(*thisMachine, NodeStatus::LEAVE);

    for(auto machine : *machine_addr){
        boost::asio::io_service leaveIOService;
        udp::resolver resolver(leaveIOService);
        udp::resolver::query q(machine.first, machine.second);
        udp::endpoint l_endpoint = *resolver.resolve(q);

        udp::socket socket(leaveIOService);
        socket.open(udp::v4());

        std::ostringstream sendBuf;
        {
            boost::archive::binary_oarchive ar(sendBuf);
            ar << leaveHeader;
        }

        try
        {
            socket.send_to(boost::asio::buffer(sendBuf.str()), l_endpoint);
        }
        catch(boost::system::system_error& e)
        {
        }

    }

    return 1;
}
