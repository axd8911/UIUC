// STL
#include <iostream>
#include <memory>
#include <vector>
#include <string>
#include <fstream>
#include <utility>

// Boost
#include <boost/lexical_cast.hpp>

#include "../include/FDService.hpp"

using Machines = std::vector<std::pair<std::string, std::string>>;

int main(int argc, char * argv[]) {
	// Check args
	if (argc < 3) {
		std::cout << "Usage: " << argv[0] << " <port number>"
				<< " <address file>" << std::endl;
		return 1;
	}
	// Assign port
	unsigned short portNum = boost::lexical_cast<unsigned short>(argv[1]);

	// Read optional params
	bool logVerbose = false;
	bool falsePositiveTest = false;
	for(int i = 3; i < argc; ++i){
		std::string arg;
		arg.assign(argv[i]);
		if(arg == "-v" || arg == "--verbose"){
			logVerbose = true;
		}else if(arg == "-f" || arg == "--false-positive-test"){
			falsePositiveTest = true;
		}
	}

	// Read in the other server addresses
	std::string addrFileName;
	addrFileName.assign(argv[2]);
	std::shared_ptr<Machines> machine_addr = std::make_shared<Machines>();
	std::fstream addr_file;
	std::string temp;
	addr_file.open(addrFileName, std::ios::in);

	while (!addr_file.eof()) {
		std::getline(addr_file, temp);
		if (temp[0] == '-' || temp[0] == '#') {
			// If the first char is a dash or a pound sign, then ignore this line
			// This allows for commenting in the address file
			continue;
		}
		int delim = temp.find(":");
		if (delim < 0) {
			// If the line read before did not have a colon in it, it is not an address
			continue;
		}
		std::string addr = temp.substr(0, delim);
		std::string port = temp.substr(delim + 1);
		machine_addr->push_back(std::make_pair(addr, port));
	}
	addr_file.close();

	std::shared_ptr<FDService> fds = std::make_shared<FDService>(portNum,
			machine_addr, logVerbose, falsePositiveTest);
}

