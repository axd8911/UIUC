#include <Header.hpp>
#include <stddef.h>
#include <utility>

Header::Header()
{
}

Header::Header(MessageType t) : type(t)
{
}

Header::~Header()
{
}

void Header::insert(const Node & node, const NodeStatus status)
{
    nodes.insert({node, status});
}

MessageType Header::getMessageType() const
{
    return type;
}

void Header::copyFromMembershipList(const ThreadSafeMap& tsm)
{
    tsm.copyToAnotherMap(nodes);
}


size_t Header::nodesSize() const
{
    return nodes.size();
}

std::unordered_map<Node, NodeStatus, NodeHasher>::iterator Header::begin() noexcept
{
    return nodes.begin();
}

std::unordered_map<Node, NodeStatus, NodeHasher>::iterator Header::end() noexcept
{
    return nodes.end();
}

Node Header::getFirst() const {
	return nodes.begin()->first;
}
