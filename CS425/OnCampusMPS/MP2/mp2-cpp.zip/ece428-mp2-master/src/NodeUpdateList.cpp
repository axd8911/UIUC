#include "NodeUpdateList.hpp"

#include <utility>

NodeUpdateList::NodeUpdateList() {
}

NodeUpdateList::~NodeUpdateList() {
}

// Prepare the update header
void NodeUpdateList::prepareUpdateHeader(Header& header) {
	for (auto it = updateList.begin(); it != updateList.end();) {
		header.insert(std::get<0>(*it), std::get<1>(*it));
		std::get<2>(*it) += 1;
		if (std::get<2>(*it) >= MAX_UPDATE_SEND_COUNT) {
			it = updateList.erase(it);
		} else {
			++it;
		}
	}
}

void NodeUpdateList::insertUpdate(const Node& node, const NodeStatus status) {
	updateList.push_back(std::make_tuple(node, status, 0));
}
