#! /bin/bash

cd ..


# kill the server process
for g in $(ps -ef | grep "[.]/server 80" | awk '{print $2}');
do
    kill $g
done

# call the leave program
./node_leave

