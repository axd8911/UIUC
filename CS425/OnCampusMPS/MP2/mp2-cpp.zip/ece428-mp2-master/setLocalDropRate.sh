#!/bin/sh

sudo iptables -A OUTPUT -d 127.0.0.1 -m statistic --mode random --probability ${1} -j DROP
