#!/bin/sh

#echo $2
./server ${1} machine_addr.txt $2 $3
