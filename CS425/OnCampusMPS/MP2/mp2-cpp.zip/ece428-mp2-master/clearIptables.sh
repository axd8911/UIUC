#~/bin/sh

sudo iptables --flush

