# ece428-mp2

MP2 for ECE428/CS425

We wrote our MP in C++ using Boost library 1.68.0.
So a successful compilation requires Boost to be compiled first with the following static libraries:

- system
- thread
- date_time
- regex
- serialization
- filesystem

### To Compile

1. Make sure Boost is install and environment variable BOOST_PATH is set (without the final slash). If not, follow the steps in `README` document of our MP1.

2. `make` This will compile both server and the client in their sub directories. If you wish to only compile on or the other, go into their directories and `make` there.

### To Start the Service

1. `cd` into the root directory.
2. Run `./server [port number] [address book]`, where
    - [port number] is the udp port the program is going to use.
    - [address book] Two address books are used for easy local and remote testing.
		- 0 will read from file "machine_addr.txt"
		- 1 will read from file "machine_addr_vm.txt"

### To Set the Pakcet Drop Rate

1. Run script named `setLocalDropRate.sh` with the drop rate you want to specify.
2. Run script named `clearIptables.sh` to clear all the drop rate setting.




### To Leave the Cluster Voluntarily

1. Enter `leave` or `l` at the prompt of the service program.
2. The program will automatically terminate after it finish the leaving procedure.

### To Emulate Node Crash

1. Enter `ctrl + c` at the prompt of the service program to force quite the program.

### To Get the Logging information

1. Please refer to the `README` document of our MP1.


### Any problem please contact Louis (llu13) and Yifan (yifany3).