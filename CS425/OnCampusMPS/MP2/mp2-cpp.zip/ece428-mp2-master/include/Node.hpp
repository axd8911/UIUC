#pragma once
#include <string>
#include <ostream>

#include <boost/asio.hpp>
#include <boost/serialization/access.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

class Node {
public:
	Node();
	Node(std::string theirAddress, unsigned short theirPort, unsigned long theirJoinTime, unsigned int vInc);
	Node(std::string theirAddress, unsigned short theirPort, unsigned long theirJoinTime, unsigned int vInc,
			unsigned int uuid);
	Node(const Node & other);
	~Node();

	bool operator==(const Node & other) const;
	bool weakEquals(const Node & other) const;

	friend std::ostream& operator<<(std::ostream& os, const Node& n);

	unsigned int getUUID() const;
	std::string getTheirAddress() const;
	unsigned short getTheirPort() const;
	unsigned long getTheirJoinTime() const;
	unsigned int getVInc() const;

	void setVInc(unsigned int vInc);
	void incVInc();

private:
	friend class boost::serialization::access;
	template<class Archive>
	void serialize(Archive & ar, const unsigned int version) {
		ar & theirAddress;
		ar & theirPort;
		ar & theirJoinTime;
		ar & uuid;
		ar & vIncarnation;
	}

	std::string theirAddress;
	unsigned short theirPort;
	unsigned long theirJoinTime;
	unsigned int uuid;
	unsigned int vIncarnation;
};

class NodeHasher {
public:
	std::size_t operator()(const Node & n) const {
		return n.getUUID();
	}
};
