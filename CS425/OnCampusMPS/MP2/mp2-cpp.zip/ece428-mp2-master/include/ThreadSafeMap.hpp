#pragma once

#include <mutex>
#include <unordered_map>
#include <utility>
#include <vector>

#include "Node.hpp"
#include "NodeStatus.hpp"

//template<class _Key, class _Tp, class _Hash = std::hash<_Key>>
class ThreadSafeMap {
public:
	ThreadSafeMap() {
	}
	~ThreadSafeMap() {
	}

	bool empty() const {
		std::lock_guard<std::mutex> lock(m);
		return data.empty();
	}

	bool isIn(const Node & node) const {
		// Check the if key is in the map
		std::lock_guard<std::mutex> lock(m);
		auto search = data.find(node);
		if (search != data.end()) {
			// Found the same node, check if incarnation has been updated
			return true;
		}
		return false;
	}

	std::size_t size() const {
		std::lock_guard<std::mutex> lock(m);
		return data.size();
	}

	// Return true if the update node is the newest and has been inserted
	// Return false if the update node is out-dated
	bool insert(const Node & node, const NodeStatus status) {
		std::lock_guard<std::mutex> lock(m);
		// Check the if key already exists
		auto search = data.find(node);
		if (search != data.end()) {
			// Found the same node, check if incarnation has been updated
			unsigned int vInc = node.getVInc();
			if (search->first.getVInc() < vInc) {
				// This is an updated node
				data.erase(search);
				data.insert( { node, status });
				return true;
			}
			return false;
		}
		// Need to remove any duplicate of the same machine with a different time stamp
		for (auto it = data.begin(); it != data.end();) {
			if (it->first.weakEquals(node)) {
				// Same IP and port node found, then take the latest
				if (it->first.getTheirJoinTime() < node.getTheirJoinTime()) {
					it = data.erase(it);
					// Go ahead and insert the new one, no need to keep the loop
					break;
				} else {
					// Received an older update, ignore it
					return false;
				}
			}
			++it;
		}
		data.insert( { node, status });
		return true;
	}

	// return true if erased something, false otherwise
	bool erase(const Node & node) {
		std::lock_guard<std::mutex> lock(m);
		return data.erase(node) != 0;
	}

	// Returns the new node status after change
	NodeStatus updateNodeStatus(const Node & node, bool downgrade) {
		std::lock_guard<std::mutex> lock(m);
		auto nIt = data.find(node);
		if (nIt != data.end()) {
			if (downgrade) {
				// alive to suspected to failed
				if (nIt->second == NodeStatus::ALIVE) {
					nIt->second = NodeStatus::SUSPECTED;
					return NodeStatus::SUSPECTED;
				} else if (nIt->second == NodeStatus::SUSPECTED) {
					data.erase(node);
					return NodeStatus::FAILED;
				}
			} else {
				/*if (nIt->second == NodeStatus::SUSPECTED) {
					nIt->second = NodeStatus::ALIVE;
					return NodeStatus::ALIVE;
				}*/
			}
		}
		// Default return status
		return NodeStatus::EMPTY;
	}

	// Return true means the node's status is modified to a new value
	// false if the node does not exist or the new value is equal to the old one
	bool modifyNodeStatus(const Node & node, NodeStatus status) {
		std::lock_guard<std::mutex> lock(m);
		auto nIt = data.find(node);
		if (nIt != data.end()) {
			if(nIt->second == status){
				return false;
			}
			nIt->second = status;
			return true;
		}
		return false;
	}

	void copyToAnotherMap(std::unordered_map<Node, NodeStatus, NodeHasher> & copyM) const {
		std::lock_guard<std::mutex> lock(m);
		copyM.insert(data.begin(), data.end());
	}

	void copyToNodesVector(std::vector<Node> & nodes) const {
		std::lock_guard<std::mutex> lock(m);
		for (const auto &kv : data) {
			nodes.push_back(kv.first);
		}
	}

private:
	std::unordered_map<Node, NodeStatus, NodeHasher> data;

	mutable std::mutex m;
};

