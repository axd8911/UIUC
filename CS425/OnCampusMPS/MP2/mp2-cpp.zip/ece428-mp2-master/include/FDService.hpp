#pragma once

#include "Header.hpp"
#include "ThreadSafeMap.hpp"
#include "ThreadSafeVector.hpp"
#include "NodeStatus.hpp"

#include <memory>
#include <vector>
#include <string>
#include <chrono>
#include <atomic>
#include <unordered_map>
#include <fstream>
#include <mutex>

#include <boost/asio.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/optional.hpp>

class FDService {
public:
	FDService(unsigned short port, std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines,
			bool logVerbose, bool falsePositiveTest);
	~FDService();

	bool startService(unsigned short port);

private:
	const int PING_NODES_COUNT = 3;
	const int PING_WAIT_MS = 1000;
	std::atomic<bool> haveJoined;
	std::atomic<bool> haveLeft;
	std::shared_ptr<Node> thisMachine;
	std::shared_ptr<std::vector<std::pair<std::string, std::string>>> machines;
	std::string myAddr;
	std::atomic<unsigned int> pingSent;
	ThreadSafeMap members;
	boost::lockfree::spsc_queue<std::pair<Node, NodeStatus>, boost::lockfree::capacity<1024>> dissemQueue;
	std::vector<Node> contacts;
	ThreadSafeVector ackExpectations;

	std::shared_ptr<boost::asio::thread_pool> senderPool;

	bool waitForSingleAck(std::atomic<bool> & listeningFlag, const Header& header, const Node & targetNode,
			unsigned int timeOutMs);
	void pingListener(unsigned short port);
	void handleReceivedHeader(Header & header);
	void processReceivedHeader(Header & header);
	void sendHeader(const Node & n, const Header & h);
	void pingSender();
	boost::optional<Node> getNextContact();
	void checkTimeOuts(const boost::optional<Node> & ackReceivedNode);

	void writeLocalLog(char type, char status, const Node &node);
	void writeEventLog(char type, const Node &node);

	bool logVerbose;
	std::mutex logLock;
	std::ofstream f_log;

	bool falsePositiveTest;
};
