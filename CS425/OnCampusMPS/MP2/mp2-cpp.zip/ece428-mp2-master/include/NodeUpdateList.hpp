#pragma once
#include <list>
#include <tuple>

#include "Node.hpp"
#include "NodeStatus.hpp"
#include "Header.hpp"

class NodeUpdateList {
public:
	NodeUpdateList();
	~NodeUpdateList();

	void insertUpdate(const Node & node, const NodeStatus status);
	void prepareUpdateHeader(Header & header);

private:
	const int MAX_UPDATE_SEND_COUNT = 5;

	std::list<std::tuple<Node, NodeStatus, int>> updateList;
};

