#pragma once
enum class MessageType
{
    JOIN_REQ,
    JOIN_ACK,
    PING,
    //PING_REQ,
    ACK,
    LEAVE,
    LEAVE_ACK
};
