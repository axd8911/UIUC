#/bin/sh

./clearIptables.sh
timeout -sHUP 5m ./startLocalServer.sh 8009 -f &
timeout -sHUP 5m ./startLocalServer.sh 8010 -f &
timeout -sHUP 5m ./startLocalServer.sh 8011 -f &
timeout -sHUP 5m ./startLocalServer.sh 8012 -f &
./setLocalDropRate.sh $1

timeout -sHUP 5m $(read "Press")

for node in 1 2 3 4; do
 	proc="$(ps aux | grep "./server 80" | grep -v "grep" )"
	pid=$(echo $proc | sed -r 's/^([^.]+).*$/\1/; s/^[^0-9]*([0-9]+).*$/\1/')
	echo $proc
	echo $pid
	$(kill ${pid})
done
