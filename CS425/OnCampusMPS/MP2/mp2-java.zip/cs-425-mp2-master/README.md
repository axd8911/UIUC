# CS 425 MP2

To build use `mvn clean install`

To run use `java -cp cs425mp.jar edu.illinois.cs425.App`

To configure, please change properties in the `mp2AppConfig` file.