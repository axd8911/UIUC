# distributed-log-querier

CS425 FA18 MP1

Usage:
## Start the server (on each node): 
python3.6 dlq_server.py 
## query: 
python3.6 dlq_client.py <pattern>
#### example:
python3.6 dlq_client.py J6mVgP5q  
python3.6 dlq_client.py -e abc -e bca -e zaz