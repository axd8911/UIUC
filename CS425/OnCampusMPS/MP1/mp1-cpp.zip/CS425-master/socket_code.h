#ifndef SOCKET_CODE_H
#define SOCKET_CODE_H

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <chrono>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/in.h>
#include <ctime>
#include <ifaddrs.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <signal.h>

#define PORT "1200"
#define TIMEOUT 350

class Socket
{
	public:
		static int writeEverythingToSocket(const int socket_fd, const char *buff, const size_t count);
		static int readEverythingFromSocket(const int socket_fd, char * & buff);
		static int closeConnection(const int socket_fd);
};

class Client: public Socket
{
	public:
		static int createAndConnectSocket(const char* ip_address);
};

class Server: public Socket
{
	public:
		static int createAndConnectSocket();
		static int acceptConnection(const int socket_fd);
		static void printIPAddress();

	private:
		static void* getInAddr(const struct sockaddr *sa);
};

#endif
