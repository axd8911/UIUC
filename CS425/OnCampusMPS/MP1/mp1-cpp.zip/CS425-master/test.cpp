#include "test.h"

/* main test runner */
int main() {
  // TEST_OUTPUT("grepShouldWork", grepShouldWork());
  // TEST_OUTPUT("frequentPatternTest", frequentPatternTest());
  // TEST_OUTPUT("infrequentPatternTest", infrequentPatternTest());
  // TEST_OUTPUT("regularExpressionTest", regularExpressionTest());
  latencyTest();
  return 0;
}

/** TESTS **/
/* grepShouldWork
 *
 * DESCRIPTION:	Tests that `grep -i <word> <file>` commands work.
 * INPUTS:      (none)
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Calls grepCommander, which has side effects
*/
int grepShouldWork() {
  return grepCommander("AW+ui", "grep -i", "test_log.out", 4);
}


/* frequentPatternTest
 *
 * DESCRIPTION:	Tests frequnt patterns on various file sizes.
 * INPUTS:      (none)
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Calls grepCommander, which has side effects
*/
int frequentPatternTest(){
  srand((int)time(0));
  #undef MAX_FILE_LINES
  #define MAX_FILE_LINES (rand() % 100000) + 1
  return grepCommander("distributed systems is awesome", "grep -i", "test_fpt_log.out", (rand() % 100) + 1000);
}


/* infrequentPatternTest
 *
 * DESCRIPTION:	Tests infrequnt patterns on various file sizes.
 * INPUTS:      (none)
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Calls grepCommander, which has side effects
*/
int infrequentPatternTest(){
  srand((int)time(0));
  #undef MAX_FILE_LINES
  #define MAX_FILE_LINES (rand() % 100000) + 1
  return grepCommander("CS425 ftw!!!!", "grep -i", "test_ifpt_log.out", (rand() % 100) + 1);
}


/* regularExpressionTest
 *
 * DESCRIPTION:	Tests a simple regex pattern on various file sizes.
 * INPUTS:      (none)
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Calls grepCommander, which has side effects
*/
int regularExpressionTest(){
  srand((int)time(0));
  #undef MAX_FILE_LINES
  #define MAX_FILE_LINES (rand() % 10000) + 1
  return grepCommander("..425", "grep ", "test_ret_log.out", (rand() % 100) + 1000);
}


/* latencyTest
 *
 * DESCRIPTION:	Tests latencies on querring 4 servers with 60 MB files assuming querring functionality works.
 * INPUTS:      (none)
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Calls writeRemoteLog, which has side effects
*/
void latencyTest() {
            srand((int)time(0));
            // #undef MAX_FILE_LINES
            // #define MAX_FILE_LINES 629146 //total number of lines for 60MB assuming 100 byte length lines
            int tally = 0;
            std::string command = "./client machines=\"[1,2,3,4]\" command=\"grep -v the \"";
            std::vector<long> timing_arr;
            for (int i =0; i<10; i++){
                        //start time
                        auto timeStart = std::chrono::high_resolution_clock::now();

                        system(command.c_str());
                        //end time
                        auto timeEnd = std::chrono::high_resolution_clock::now();
                        timing_arr.push_back(std::chrono::duration_cast<std::chrono::milliseconds>(timeEnd - timeStart).count());
            }
            long avg=0, stnd=0;
            printf("AVERAGE:%ld\n", (avg=std::accumulate(timing_arr.begin(), timing_arr.end(), 0) / timing_arr.size()));
            for (auto& runtime : timing_arr){
                        printf("%ld\n", runtime);
                        stnd=(runtime-avg)*(runtime-avg)+stnd;
            }

            printf("STANDARD DEVIATION:%ld\n", (long) (sqrt(stnd/timing_arr.size())));
}


/** ADMINISTRATIVE FUNCTIONS **/
/* createLog
 *
 * DESCRIPTION:		A helper function to write a log, filled with random lines and `input`
 * INPUTS:      input -- the input string that will appear every `frequency` lines
                tally -- the number of lines the input string occurs in
                frequency -- dictates how often `input` is used as a log line
 * OUTPUTS:			string -- the resulting log as a string
 * SIDE EFFECTS:	updates tally
*/
std::string createLog(const std::string input, int & tally, int frequency) {
  int character;
  std::string output = "";
  std::string generation = "";

  for(int i = 0; i < MAX_FILE_LINES; ++i) {
    if(i % frequency == 0) {
      output += input;
      ++tally;
    }
    else {
      generation = Utilities::generateRandomLine(MAX_LINE_LENGTH);
      if(generation.find(input) != std::string::npos) {
        ++tally;
      }

      output += generation;
    }

    output += "\\n";
  }

  return output;
}


/* wrapLogCommand
 *
 * DESCRIPTION:		A helper function that supplies the command needed to write a string to a file
 * INPUTS:      input -- the input string that will be written to `file_name`
                file_name -- the file that we wish to write `input` to
 * OUTPUTS:			string -- the resulting command as a string
 * SIDE EFFECTS: (none)
*/
std::string wrapLogCommand(const std::string input, const std::string file_name) {
  return  "echo -e $'" + input + "' > " + file_name;
}

/* wrapClientCommand
 *
 * DESCRIPTION:		A helper function that supplies the command needed to call the client process with command `input`
 * INPUTS:      input -- the input command we wish to send as a request
 * OUTPUTS:			string -- the resulting command as a string
 * SIDE EFFECTS: (none)
*/
std::string wrapClientCommand(const std::string input) {
  return "./client machines=\"all\" command=\"" + input + "\" env=\"test\"";
}

/* writeRemoteLog
 *
 * DESCRIPTION:	A test setup function that leverages helper functions to create a log, and send it
                over the client to be written to a given file remotely
 * INPUTS:      input -- the input string that will appear every `frequency` lines
                tally -- the number of times `input` appears in the log
                frequency -- the number of lines that we will write `input` to the log
                file_name -- the output file name that remote servers will write the log to
 * OUTPUTS:			int -- a successful return
 * SIDE EFFECTS: Creates remote logs with `file_name` on every server
*/
int writeRemoteLog(std::string input, int & tally, int frequency, const std::string file_name) {
  std::string command = wrapLogCommand(createLog(input, tally, frequency), file_name);
  std::string abc = wrapClientCommand(command) + " > distributed_log_test.out";
  system(abc.c_str());
  return 0;
}


/* grepCommander
 *
 * DESCRIPTION:	A test base that is used to test grep cases for our distributed system
 * INPUTS:      match -- the word that we wish to check the occurrence of
                command -- the grep command structure, so that we can test different matcher flags
                file_name -- the output file name that remote servers will write the log to
                frequency -- the frequency at which `match` will appear in our created logs
 * OUTPUTS:			int -- 1 is considered a test PASS, 0 is considered a test FAIL
 * SIDE EFFECTS: Creates remote logs with `file_name` on every server, creates a local log file with results
                `distributed_log_test.out`
*/
int grepCommander(
  const std::string match,
  const std::string command,
  const std::string file_name,
  const int frequency
)
{
  int tally = 0;
  writeRemoteLog(match, tally, frequency, file_name);
  const std::string input = command + " " + match + " " + file_name;
  std::string executor = wrapClientCommand(input) + " > distributed_log_test.out";

  std::vector<std::string> responses = getParsedOutput();

  if(responses.size() == 0) return FAIL;

  for(size_t i = 0; i < responses.size(); ++i) {

    if(responses[i].compare(responses[0]) != 0) {
      return FAIL;
    }
  }

  return PASS;
}

/* getParsedOutput
 *
 * DESCRIPTION:	A helper function that reads from our local logfile and gets each server's response
 * INPUTS:     (none)
 * OUTPUTS:			vector<string> -- the responses from each server, in no particular order
 * SIDE EFFECTS: (none)
*/
std:: vector<std::string> getParsedOutput() {
  std::ifstream file("distributed_log_test.out");

  std::vector<std::string> output;
  std::string line;
  std::string data = "";
  while(std::getline(file, line)) {
    if(line.find("MACHINE") != std::string::npos || line.find("Connection failure") != std::string::npos) {
      if(!data.empty()) output.push_back(data);
      data = "";
    }
    else {
      data += line;
    }
  }

  if(!data.empty()) output.push_back(data);
  return output;
}
