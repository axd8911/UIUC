#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

#include <iostream>
#include <vector>

#include "utilities.h"
#include "socket_code.h"

/* clientRunner
 *
 * DESCRIPTION:	The client runner thread - opens up a socket connection, sends over request data,
 								receives response data, and outputs to terminal
 * INPUTS:      client_args -- a struct containing:
 									# machine_number -- the server machine number, as identified in machine_mapping.txt
									# ip_address - the server ip_address, as identified in machine_mapping.txt
									# command -- the command argument provided from execution
 * OUTPUTS:			(none)
 * SIDE EFFECTS: Multithreaded
*/
void *clientRunner(void* args) {
	struct client_args *input = (struct client_args *)args;
	const char* cmd = (char*)input->command.c_str();
	const int socket_fd = Client::createAndConnectSocket((char*)(input->ip_address).c_str());

	if(socket_fd != -1) {
		char *response = NULL;

		Socket::writeEverythingToSocket(socket_fd, cmd, strlen(cmd));
		int buffer_size = 0;
		while(!buffer_size){
			ioctl(socket_fd, FIONREAD, &buffer_size);
		}
		if(-1 == Socket::readEverythingFromSocket(socket_fd, response)) {
			printf("MACHINE %d RESPONSE:\nConnection failure. Machine is unavailable\n", input->machine_number);
			pthread_exit(NULL);
		}

		printf("MACHINE %d RESPONSE:\n%s\n", input->machine_number, response);

		Client::closeConnection(socket_fd);
		free(response);
	}
	else {
		printf("MACHINE %d RESPONSE:\nConnection failure. Machine is unavailable\n", input->machine_number);
	}

  pthread_exit(NULL);
}


/* main
 *
 * DESCRIPTION:	The base client process - ensures that the executable is run correctly,
 								differentiates test runs from actual runs, parses input parameters, and runs each
								request in new threads.
 * INPUTS:      machines= -- the machines to send the request to. Can either be an array or "all".
 															Check the README for more information.
								command= -- The command for the remote machines to execute.
								env= -- the environment to be used. Defaults to production, unless specified as test
 * OUTPUTS:			(none)
 * SIDE EFFECTS: Multithreaded
*/
int main(int argc, char **argv){
  size_t i = 0;
  if(argc < 3) Utilities::printUsage();

	bool development = true;
	if(argc >= 4) {
		std::string env(argv[3]);
		if(env.find("env=test") != std::string::npos) {
			development = false;
		}
	}

  const std::map<int, std::string> server_map = Utilities::getMachineTBUMap(argv[1]);
  pthread_t threads[server_map.size()];

  for(auto it: server_map) {
    struct client_args *args = new client_args;
    args->machine_number = it.first;
    args->ip_address = it.second;
    args->command = Utilities::commandMarshaller(argv[2], it.first, development);
    pthread_create(&threads[i++], NULL, clientRunner, args);
  }

  for(size_t j = 0; j < i; ++j){
    pthread_join(threads[j], NULL);
  }

  pthread_exit(NULL);
}
