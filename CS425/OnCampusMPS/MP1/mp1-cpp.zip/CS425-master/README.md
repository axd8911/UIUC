# Distributed Grep

## About

### Summary
This project implements distributed grep, which allows for a user to query the logs of multiple machines from a single machine in a distributed cluster, and view the results. All source files are written in C/C++.

### Architecture
The cluster follows the traditional client-server model for a cluster of machines. Every single machine in the cluster runs the server process in order to be remotely queryable. To query a range of machines in the network, a host machine runs the client process and supplies the necessary arguments, as clarified in the *Usage* section. Both the client and server process are multithreaded, allowing for requests from the client to be sent out to multiple machines in tandem, and for servers to respond to multiple client requests concurrently and efficiently. Servers will run until the process is stopped, while client processes are for a single query only.

This project requires a network of computers, and their associated addresses. This information has been specified in `machine_mapping.txt`, and must be overwritten for actual use. Each entry in `machine_mapping.txt` follows the form `<machine_number> <address>`.

The system is designed to be fault tolerant and efficient - the client compiles the output of all servers that respond, but does not consider lack of response from a given server to be a critical failure. Both the server and client have timeout clauses when attempting to read from a socket buffer, so that queries are timely. Buffer reads allocate only enough memory to read the entire buffer, no more or less. Since this is a closed network, the client and server processes have a hard limit on the number of parallel threads that can be running at a given time.

## Usage

### Compilation
The *client*, *server*, and *test* executables can be compiled by simply running `make` in the main directory. To remove the executables and related object files, run `make tidy`.

### Running a query
As mentioned earlier, in order to run a query that targets a specified server machine, the server process must be running on the target machine. Prior to running a query, server processes on all target computers must be started by running `./server`.

In order to submit a command, the user should run `./client machines=<machine_list> command=<command>`.
The `<machine_list>` argument accepts two forms:
* "all" - This parameter specifies that the command should target every machine in the network. For example, `./client machines="all" command="grep -i 'abc'"`
* "[1, 2, 3]", An array of target machine numbers - This parameter specifies that the command should target the machines with the associated numbers. To understand how machine numbers correspond to addresses, view `machine_mapping.txt`. For example, `./client machines=[1, 5, 7, 3, 9] command="grep -i 'abc'"` would target machines 1, 3, 5, 7, and 9.

The `<command>` argument is simply the command to be executed: For example, `./client machines="all" command="ls"` would execute 'ls' on every machine in the cluster, and return the directory list for every machine to the querying machine. While this project was structured to support `grep` specifically, the command argument can be more general. The assumption here is that the user has access rights to all machines, and can execute these commands on each target machine directly - therefore, there is no further security risk exposed by this functionality.


## Tests

### Setup/Execution
In order to run tests, you must first:
* Compile all executables
* Run `./server` on at least two machines (since some tests require comparison between responses)

Then, simply run `./test` - The output will tell you which tests in the suite are failing/passing.
