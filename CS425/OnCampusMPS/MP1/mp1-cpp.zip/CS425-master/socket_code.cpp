#include "socket_code.h"


/** BASE SOCKET CLASS FUNCTIONS **/

/* writeEverythingtoSocket
 *
 * DESCRIPTION:	Supports error handling around a socket write command
 * INPUTS:      socket_fd -- the file descriptor for the open socket
 								buff -- the buffer from which the request data is gathered
								count -- the size of the buffer
 * OUTPUTS:			int -- the number of bytes written to the socket
 * SIDE EFFECTS: (none)
*/
int Socket::writeEverythingToSocket(const int socket_fd, const char *buff, const size_t count) {
	int bytes_wrote;
	size_t bcount = 32767;
	size_t total_bytes = 0;
	while(total_bytes < count){
		if(count - total_bytes < bcount){
			bcount = count - total_bytes;
		}
		if((bytes_wrote = write(socket_fd, &buff[total_bytes], bcount)) == -1){
			perror("write");
			exit(-1);
		}
		total_bytes += bytes_wrote;

	}


	return total_bytes;
}

/* readEverythingFromSocket
 *
 * DESCRIPTION:	Supports error handling around a socket read command
 * INPUTS:      socket_fd -- the file descriptor for the open socket
 								buff -- the buffer into which response data will be appended
 * OUTPUTS:			int -- the number of bytes written to the buffer
 * SIDE EFFECTS: (none)
*/
int Socket::readEverythingFromSocket(const int socket_fd, char * & buff) {
	auto start = std::chrono::high_resolution_clock::now();

	//end time

	std::string data = "";
	int buffer_size = -1, bytes_read = 0;

	while(1) {
		start = std::chrono::high_resolution_clock::now();
		while (buffer_size == -1 || !buffer_size) {
			auto end = std::chrono::high_resolution_clock::now();
			if(std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() > TIMEOUT) {
				buff = (char*)(malloc(data.size() + 1 * sizeof(char)));
				strcpy(buff, data.c_str());
				return data.size();
			}
			ioctl(socket_fd, FIONREAD, &buffer_size);
		}

		/* Allocate char array on heap, and read in buffer */
		buff = (char*)(malloc((buffer_size + 1) * sizeof(char)));
		if((bytes_read = read(socket_fd, buff, buffer_size)) == -1) {
				perror("read");
				break;
	 	}
		buff[bytes_read] = '\0';

		data.append(buff);
		free(buff);
		buffer_size = -1;
	}
	/* Query for receive buffer size, timing out after TIMEOUT seconds */

	buff = (char*)(malloc(data.size() + 1 * sizeof(char)));
	strcpy(buff, data.c_str());
	return data.size();
}

/* closeConnection
 *
 * DESCRIPTION:	Wraps error handling around socket close function
 * INPUTS:      socket_fd -- the socket file descriptor to close
 * OUTPUTS:			int -- 0 if successful, -1 if not
 * SIDE EFFECTS: Prints to terminal in case of failure
*/
int Socket::closeConnection(const int socket_fd) {
	if (close(socket_fd) == 0)
		return 0;
	else {
		printf("Either the the socket was already closed or some other error.\n");
		return -1;
	}
}

/** CLIENT SOCKET FUNCTIONS **/

/* createAndConnectSocket
 *
 * DESCRIPTION:	Connects socket from client side, constructed from ip address
 * INPUTS:      ip_address -- the ip_address of the machine to connect to
 * OUTPUTS:			int -- -1 if unsuccessful, or the socket file descriptor if successful
 * SIDE EFFECTS: Opens a connection
*/
int Client::createAndConnectSocket(const char * ip_address) {
	int address_info;
	const int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
	struct addrinfo hints, *result;
	memset(&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_INET; /* IPv4 only */
	hints.ai_socktype = SOCK_STREAM; /* TCP */

	if ((address_info = getaddrinfo(ip_address, PORT, &hints, &result)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(address_info));
		return -1;		// Client failures should not be terminating
	}

	if (connect(socket_fd, result->ai_addr, result->ai_addrlen) == -1) {
		//perror("connect");
		return -1;		// Client failures should not be terminating entire process
	}

	return socket_fd;
}

/** SERVER SOCKET FUNCTIONS **/

/* createAndConnectSocket
 *
 * DESCRIPTION:	Connects socket from server side - socket, bind, listen
 * INPUTS:      (none)
 * OUTPUTS:			int -- the socket file descriptor if successful
 * SIDE EFFECTS: Can critically fail if there is a failure with any critical portion
*/
int Server::createAndConnectSocket() {
	int address_info, new_fd;
	const int flag_value = 1;
	const int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
	char s_arr[INET6_ADDRSTRLEN];

	struct addrinfo hints, *result;
	memset(&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	if ((address_info = getaddrinfo(NULL, PORT, &hints, &result)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(address_info));
		exit(1);
	}

	if (bind(socket_fd, result->ai_addr, result->ai_addrlen) != 0) {
		perror("bind()");
		exit(1);
	}

	setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, &flag_value, sizeof(flag_value));

	if (listen(socket_fd, 10) != 0) {
		perror("listen()");
		exit(1);
	}

	return socket_fd;
}

/* acceptConnection
 *
 * DESCRIPTION:	Accepts a connection from the server side.
 * INPUTS:      socket_fd -- the open server socket
 * OUTPUTS:			int -- the file descriptor for the new connection
*/
int Server::acceptConnection(const int socket_fd){
	int new_fd;
	socklen_t sin_size;
	struct sockaddr_storage their_addr; // connector's address information
	char s_arr[INET6_ADDRSTRLEN];
	sin_size = sizeof(their_addr);
	if ((new_fd = accept(socket_fd, (struct sockaddr *)&their_addr, &sin_size)) == -1) {
		perror("accept");
	}

	inet_ntop(their_addr.ss_family, getInAddr((struct sockaddr *)&their_addr), s_arr, sizeof(s_arr));
	printf("server: got connection from %s\n", s_arr);
	return new_fd;
}

/* printIPAddress
 *
 * DESCRIPTION:	Helper function to print local machine's IP Address
 * INPUTS:      (none)
 * OUTPUTS:			(none)
 * SIDE EFFECTS: prints out machine's IP Address
*/
void Server::printIPAddress() {
	int required_family = AF_INET;
	struct ifaddrs *myaddrs, *ifa;
	getifaddrs(&myaddrs);
	char host[256], port[256];
	for (ifa = myaddrs; ifa != NULL; ifa = ifa->ifa_next) {
		int family = ifa->ifa_addr->sa_family;
		if (family == required_family && ifa->ifa_addr) {
			if (0 == getnameinfo(ifa->ifa_addr, (family == AF_INET) ? sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6), host, sizeof(host), port, sizeof(port), NI_NUMERICHOST | NI_NUMERICSERV  )){
				printf("%s\n", host);
			}
		}
	}
}

/* getInAddr
 *
 * DESCRIPTION:	Private helper function to print local machine's IP Address
 * INPUTS:      sa -- a pointer to the reference sockaddr struct
 * OUTPUTS:		  void* -- returns a pointer to the correct protocol's address
 * SIDE EFFECTS: (none)
*/
void* Server::getInAddr(const struct sockaddr *sa) {
	return sa->sa_family == AF_INET
		? (void *) &(((struct sockaddr_in*)sa)->sin_addr)
		: (void *) &(((struct sockaddr_in6*)sa)->sin6_addr);
}
