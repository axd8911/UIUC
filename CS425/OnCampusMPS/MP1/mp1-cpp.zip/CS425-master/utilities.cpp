#include "utilities.h"

/* getMachineMap
 *
 * DESCRIPTION:	Helper function to get a mapping of machine_number to ip_address, using
 								machine_mapping.txt
 * INPUTS:      (none)
 * OUTPUTS:			map<int, string> -- the mapping of machine_number to ip_address
 * SIDE EFFECTS: (none)
*/
std::map<int, std::string> Utilities::getMachineMap() {
	std::string line;
	std::string machine_number, ip_address;
	std::map<int, std::string> machine_map;
	std::ifstream file(MAP_FILE);
	if(file.is_open()){
		while(std::getline(file, line)){
			std::istringstream stream(line);
			if(stream >> machine_number >> ip_address){
				machine_map[std::stoi(machine_number)] = ip_address;
			}
		}
		file.close();
	}
	else {
		printf("Error in getMachineMap!");
	}
	return machine_map;
}

/* getMachineTBUMap
 *
 * DESCRIPTION:	Gets the map of used machines for the execution request
 * INPUTS:      machines -- a char[] specifying the machines needed for the current execution
 * OUTPUTS:			map<int, string> -- the mapping of machine_number to ip_address for used machines
 * SIDE EFFECTS: (none)
*/
std::map<int, std::string> Utilities::getMachineTBUMap(char * machines) {
	std::set<int> machine_nums_set = parseServers(machines);
	std::map<int, std::string> machine_map = getMachineMap();
	std::map<int, std::string> output_map;
	for(auto machine : machine_nums_set) {
		if(machine_map.find(machine) != machine_map.end() ) {
			output_map[machine] = machine_map[machine];
		}
	}
	return output_map;
}

/* getMachineLog
 *
 * DESCRIPTION:	Helper function to get the name of a given machine's associated log
 * INPUTS:      machine -- the number of the machine
 * OUTPUTS:			string -- the filename of the machine's log
 * SIDE EFFECTS: (none)
*/
std::string Utilities::getMachineLog(const int machine) {
	return "vm" + std::to_string(machine) + ".log";
}

/* isGrepCommand
 *
 * DESCRIPTION:	Helper function to check whether an input command is a grep command
 * INPUTS:      command -- the input command string
 * OUTPUTS:		  bool -- whether the input command is a grep command
 * SIDE EFFECTS: (none)
*/
bool Utilities::isGrepCommand(const std::string command) {
	return command.find("grep") != std::string::npos;
}

/* commandMarshaller
 *
 * DESCRIPTION:	Helper function to remove argument prefix from the command parameter, and to
 								add arguments if the command is a grep command. If environment is test, we do not
								specify the file to be queried - otherwise, we do
 * INPUTS:      cmd -- the input command
 								machine -- the machine to run the command on
								environment -- specifies whether the environment is normal(true) or test(false)
 * OUTPUTS:			string -- the output command to be fed in the request
 * SIDE EFFECTS: (none)
*/
std::string Utilities::commandMarshaller(const char* cmd, int machine, bool environment) {
	std::string const prefix(CMD_PREFIX);
	std::string command(cmd);
	size_t erase_position = command.find(prefix);
	if(erase_position == std::string::npos){
		printUsage();
		exit(0);
	}

	command.erase(erase_position, prefix.size());
	if(isGrepCommand(command) && environment) {
		command += " " + getMachineLog(machine);
	}

	return command;
}

/* executeCommand
 *
 * DESCRIPTION:	If the command is a grep command, it conducts two executions - one for matching lines,
 								one for the line count.
								Otherwise, executes the command directly
 * INPUTS:      input -- the input command
 * OUTPUTS:			string -- the output from executing the command
 * SIDE EFFECTS: (none)
*/
std::string Utilities::executeCommand(const char* input) {
	std::string const cmd(input);
	std::string linecount_cmd, execution_cmd;
	if(isGrepCommand(cmd)) {
		linecount_cmd = cmd + " -c";
		execution_cmd = cmd + " -Hn";

		std::string linecount = executeMarshalledCommand((char*)linecount_cmd.c_str());
		std::string execution = executeMarshalledCommand((char*)execution_cmd.c_str());

		return "Number of lines: " + linecount + execution;
	}

	else {
		return executeMarshalledCommand(input);
	}
}

/* executeMarshalledCommand
 *
 * DESCRIPTION:	Helper function to conduct a system call with the query, and pipe the output to a buffer
 * INPUTS:      input -- the input command
 * OUTPUTS:			string -- the output of the command
 * SIDE EFFECTS: (none)
*/
std::string Utilities::executeMarshalledCommand(const char* input) {
	std::string data;
	FILE * stream;
	char buffer[MAX_BUFFER];
	stream = popen(input, "r");
	if (stream) {
	while (!feof(stream))
		if (fgets(buffer, MAX_BUFFER, stream) != NULL) data.append(buffer);
			pclose(stream);
	}
	return data;
}

/* parseServers
 *
 * DESCRIPTION:	Helper function to parse the input machines parameter. If the input is an array,
  							then every machine in the array is selected. If the input is "all", then all machines
								are selected.
 * INPUTS:      input -- the input char[] parameter
 * OUTPUTS:			set<int> -- the set of machines to be requested
 * SIDE EFFECTS: prints proper usage of client executable if the paramter is invalid
*/
std::set<int> Utilities::parseServers(char* input) {
	std::set<int> server_set;
	if(strstr(input, "all")) {
		for(int i = 0; i < SERVER_COUNT; i++){
			server_set.insert(i);
		}
	}

	else if(strstr(input, "[") && strstr(input, "]")){
		char * pch = strtok (input, "machines= [,]");
		while (pch != NULL){
			server_set.insert(atoi(pch));
			pch = strtok(NULL, "machines= [,]");
		}
	}
	else{
		printUsage();
	}

	return server_set;
}

/* generateRandomLine
 *
 * DESCRIPTION:	Helper function to generate a random string.
 * INPUTS:      length -- the maximum string length allowed.
 * OUTPUTS:			string -- the output generated string
 * SIDE EFFECTS: (none)
*/
std::string Utilities::generateRandomLine(int length) {
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::string output = "";
	std::set<int> disallowed = {58, 59, 91, 92, 93, 94, 96};
	int random;
	std::default_random_engine generator (seed);
  std::uniform_int_distribution<int> distribution(48, 122);

	for(int i  = 0; i < length; i++) {
		random = distribution(generator);
		if(disallowed.find(random) == disallowed.end()) {
			output += (char)random;
		}
	}

	return output;
}

/* printUsage
 *
 * DESCRIPTION:	Helper function to print correct usage of client executable
 * INPUTS:      (none)
 * OUTPUTS:			(none)
 * SIDE EFFECTS: prints to terminal
*/
void Utilities::printUsage() {
	printf("./client machines=[1,2,...,i] command=\"grep -i \" word\"\"\n");
	exit(0);
}
