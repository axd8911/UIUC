/**
 * @file utilities.h
 * Utilities class definition
 */

#ifndef UTILITIES_H
#define UTILITIES_H

#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <iostream>
#include <istream>
#include <string>
#include <ctime>
#include <set>
#include <numeric>
#include <map>
#include <random>
#include <chrono>
#include <vector>

#define MAP_FILE "machine_mapping.txt"
#define CMD_PREFIX "command="
#define SERVER_COUNT 11
#define MAX_BUFFER 1024
/**
 * Distributed System Utilities
 */

 struct client_args {
	 int machine_number;
	 std::string ip_address;
	 std::string command;
 };

class Utilities
{
	public:
		static std::map<int, std::string> getMachineMap();
		static std::map<int, std::string> getMachineTBUMap(char * machines);
		static std::string getMachineLog(const int machine);

    static std::set<int> parseServers(char* input);
		static std::string commandMarshaller(const char* command, int machine, bool environment);

    static bool isGrepCommand(const std::string command);
    static std::string executeCommand(const char* input);
		static std::string executeMarshalledCommand(const char* input);
    static std::string generateRandomLine(int length);

		static void printUsage();
};

#endif
