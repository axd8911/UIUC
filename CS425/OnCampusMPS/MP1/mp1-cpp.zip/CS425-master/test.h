#ifndef TEST_H
#define TEST_H

#define TEST_HEADER 	\
	printf("[TEST %s] Running %s at %s:%d\n", __FUNCTION__, __FUNCTION__, __FILE__, __LINE__)
#define TEST_OUTPUT(name, result)	\
	printf("[TEST %s] Result = %s\n", name, (result) ? "PASS" : "FAIL");

#define PASS 1
#define FAIL 0
#define MAX_FILE_LINES 50
#define MAX_LINE_LENGTH 100

#include <regex>
#include <chrono>
#include <vector>
#include "utilities.h"

std::string createLog(const std::string input, int & tally, int frequency);
std::string wrapLogCommand(const std::string input, const std::string file_name);
std::string wrapClientCommand(const std::string input);
int writeRemoteLog(std::string input, int & tally, int frequency, const std::string file_name);
int grepCommander(const std::string match, const std::string command, const std::string file_name, const int frequency);
std:: vector<std::string> getParsedOutput();
int grepShouldWork();
int frequentPatternTest();
int infrequentPatternTest();
int regularExpressionTest();
void latencyTest();
int main();

#endif
