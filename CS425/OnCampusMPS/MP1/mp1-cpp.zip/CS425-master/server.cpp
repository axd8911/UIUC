#include "socket_code.h"
#include "utilities.h"
#include <ctime>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <thread>
#include <iostream>

/* serverRunner
 *
 * DESCRIPTION:	The server runner thread function - serves a single connection, including interpreting
 								the request, executing any commands, and sending response data over the socket.
 * INPUTS:      args -- pointer to the integer data of the file descriptor for the connection
 * OUTPUTS:			(none)
 * SIDE EFFECTS: Multithreaded
*/
void* serverRunner(void* args) {
	const int new_fd = *(int *)args;
	char * buff = NULL;
	if (Socket::readEverythingFromSocket(new_fd, buff) != -1) {
	//	printf("%s\n", buff);

		std::string output = Utilities::executeCommand(buff);
		if(!output.size()) {
			output = "command executed";
		}

		free(buff);
		if (Socket::writeEverythingToSocket(new_fd, output.c_str(), output.size()) == -1)
			perror("send");
	}
	Server::closeConnection(new_fd);

	pthread_exit(NULL);
}

/* main
 *
 * DESCRIPTION:	The base server process - creates the socket, accepts incoming connections,
 								and runs each connection's request in a thread
 * INPUTS:      (none)
 * OUTPUTS:			(none)
 * SIDE EFFECTS: Multithreaded
*/
int main(int argc, char **argv) {
	const int socket_fd = Server::createAndConnectSocket();
	Server::printIPAddress();
	printf("Waiting for connection...\n");
	while(1) {  // main accept() loop
		int new_fd = Server::acceptConnection(socket_fd);
		if(new_fd != -1) {

			pthread_t thread;
			pthread_create(&thread, NULL, serverRunner, &new_fd);
		}
	}
	Server::closeConnection(socket_fd);

	pthread_exit(NULL);
}
