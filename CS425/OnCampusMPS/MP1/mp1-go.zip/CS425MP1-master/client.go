package main

import (
	"fmt"
	"net/rpc"
	"os"
	"path/filepath"
	"sync"

	"github.com/mp1/logging"
)

type RequestOutcome struct {
	ms       *MachineSpec // it's useful to remember the destination of the request
	err      error
	response *GrepResult
}

// HandleOneClient makes client call
func HandleOneClient(ms MachineSpec, FLAGS *Flags) chan RequestOutcome {
	logging.Info.Println("Handling Client: ", ms.URL)
	roCh := make(chan RequestOutcome)
	go func() {
		client, err := rpc.DialHTTP("tcp", ms.URL+":"+fmt.Sprintf("%d", FLAGS.Port))
		if err != nil {
			logging.Warning.Println(err)
			roCh <- RequestOutcome{&ms, err, nil}
			return
		}
		var reply GrepResult
		err = client.Call("Grep.Parse", GrepSpec{Path: ms.Path, Query: FLAGS.Query}, &reply)
		if err != nil {
			logging.Warning.Println(err)
			roCh <- RequestOutcome{&ms, err, nil}
			return
		}
		roCh <- RequestOutcome{&ms, nil, &reply}
	}()
	return roCh
}

func merge(chs []chan RequestOutcome) chan RequestOutcome {
	out := make(chan RequestOutcome)
	var wg sync.WaitGroup
	wg.Add(len(chs))
	for _, c := range chs {
		go func(c chan RequestOutcome) {
			out <- (<-c)
			wg.Done()
		}(c)
	}
	go func() {
		wg.Wait()
		close(out) // we need to close the out channel because main goroutine will later be ranging over it
	}()
	return out
}

func HandleClients(mss []MachineSpec, FLAGS *Flags) {
	chs := make([]chan RequestOutcome, 0)
	for _, ms := range mss {
		ch := HandleOneClient(ms, FLAGS)
		chs = append(chs, ch)
	}
	out := merge(chs)
	totalCount := 0
	for ro := range out {
		fmt.Printf("Machine Name: %s\n", ro.ms.URL)
		if ro.err != nil {
			fmt.Println("Error: ", ro.err.Error())
		} else {
			totalCount += ro.response.LineCount
			fmt.Println("Log file: ", ro.response.Filename)
			filename := filepath.Base(ro.response.Filename)
			if FLAGS.ToFile {
				resFile, err := os.OpenFile(filename, os.O_WRONLY|os.O_CREATE, 0777)
				if err != nil {
					logging.Error.Fatalln(err)
				}
				resFile.WriteString(ro.response.Result)
				resFile.Close()
			} else {
				fmt.Println(ro.response.Result)
			}
		}
	}
	fmt.Printf("Lines: %d\n", totalCount)
}
