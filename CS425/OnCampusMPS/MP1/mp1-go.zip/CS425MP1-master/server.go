package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"net/rpc"
	"time"

	"github.com/mp1/logging"
	cache "github.com/patrickmn/go-cache"
)

// HandleServer launches the server
func HandleServer(FLAGS *Flags) {
	grep := new(Grep)
	if FLAGS.FlagCache {
		grep.Gcache = cache.New(
			time.Duration(FLAGS.CacheExpiration)*time.Minute,
			time.Duration(FLAGS.CleanInterval)*time.Minute)
	}
	rpc.Register(grep)
	rpc.HandleHTTP()
	port := fmt.Sprintf("%d", FLAGS.Port)
	logging.Info.Println("Server launched at port: " + port)
	l, e := net.Listen("tcp", ":"+port)
	if e != nil {
		logging.Error.Fatal("listen error:", e)
	}
	log.Fatal(http.Serve(l, nil))
}
