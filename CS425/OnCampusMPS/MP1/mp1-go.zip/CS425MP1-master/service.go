// this file defines the rpc service "grep" to be registered to the server
package main

import (
	"bytes"
	"errors"
	"io/ioutil"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/mp1/logging"
	"github.com/patrickmn/go-cache"
)

// Grep is the service
type Grep struct {
	Gcache *cache.Cache
}

// GrepSpec contains infomation needed by grep
type GrepSpec struct {
	Path  string
	Query string
}

// GrepResult is the query result of grep
type GrepResult struct {
	Query     string
	Filename  string
	ModTime   time.Time
	Result    string
	LineCount int
}

// Parse runs through the log and send the result back to the client
func (g *Grep) Parse(gs GrepSpec, result *GrepResult) error {

	logging.Info.Println("Receiving Grep Command: ", gs.Query)
	// validate path
	if _, err := os.Stat(gs.Path); err != nil {
		return err
	}
	files, err := ioutil.ReadDir(gs.Path)
	if err != nil {
		return err
	}

	// validate file
	var logfile *os.File
	logRe := regexp.MustCompile("machine.[0-9]+.log")
	var logFilePath string
	for _, f := range files {
		if logRe.Match([]byte(f.Name())) {
			logging.Info.Printf("Found logfile %s/%s\n", gs.Path, f.Name())
			fpath := filepath.Join(gs.Path, f.Name())
			logFilePath = fpath
			if logfile, err = os.Open(fpath); err != nil {
				return err
			}
			defer logfile.Close()
			break
		}
	}
	if logfile == nil {
		return errors.New("Log file not found under given directory")
	}

	info, err := os.Stat(logFilePath)
	if err != nil {
		return errors.New("Stats of the log file cannot be accessed")
	}

	//Retrieve cache
	if g.Gcache != nil {
		if cache, found := g.Gcache.Get(gs.Query); found {
			grepResultCache := cache.(*GrepResult)
			if grepResultCache.ModTime == info.ModTime() {
				logging.Info.Printf("Cache HIT of \"%s\" for \"%s\"\n", logFilePath, gs.Query)
				*result = *grepResultCache
				return nil
			}
		}
	}

	if err = os.Chdir(gs.Path); err != nil {
		logging.Warning.Println("Failed to cd")
		return err
	}

	//Execute grep
	sbOut := bytes.NewBuffer(nil)
	sbErr := bytes.NewBuffer(nil)
	query := strings.Fields(gs.Query)
	exeName, exeArgs := query[0], query[1:]
	cmd := exec.Command(exeName, exeArgs...)
	cmd.Stdin = logfile
	cmd.Stdout = sbOut
	cmd.Stderr = sbErr

	err = cmd.Run()

	count := 0
	var ret string
	if err != nil {
		logging.Info.Println("An error occurred when grepping: ", err)
		ret = sbErr.String()
	} else {
		logging.Info.Println("No error occurred when grepping")
		ret = sbOut.String()
		for _, ch := range ret {
			if ch == '\n' {
				count++
			}
		}
	}

	*result = GrepResult{
		Query:     gs.Query,
		Filename:  logfile.Name(),
		ModTime:   info.ModTime(),
		Result:    ret,
		LineCount: count,
	}

	//Update cache
	if g.Gcache != nil {
		g.Gcache.Set(gs.Query, result, cache.DefaultExpiration)
		logging.Info.Printf("Cache MISS of \"%s\" for \"%s\"\n", logFilePath, gs.Query)
	}
	return nil
}
