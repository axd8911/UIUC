package logging

import (
	"io"
	"log"
	"os"
)

// loggers for different purposes
var (
	Debug   *log.Logger
	Info    *log.Logger
	Warning *log.Logger
	Error   *log.Logger
)

func init() {
	var ( // may be redirected
		debugHandle   io.Writer = os.Stdout
		infoHandle    io.Writer = os.Stdout
		warningHandle io.Writer = os.Stderr
		errorHandle   io.Writer = os.Stderr
	)
	Debug = log.New(debugHandle, "DEBUG: ", log.LstdFlags|log.Lshortfile)
	Info = log.New(infoHandle, "INFO: ", log.LstdFlags|log.Lshortfile)
	Warning = log.New(warningHandle, "WARNING: ", log.LstdFlags|log.Lshortfile)
	Error = log.New(errorHandle, "ERROR: ", log.LstdFlags|log.Lshortfile)
}
