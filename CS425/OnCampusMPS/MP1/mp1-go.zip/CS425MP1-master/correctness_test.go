package main

import (
	"bytes"
	"os"
	"os/exec"
	"strings"
	"testing"
)

func checkRegex(t *testing.T, grepQuery string, logFilename string) {
	gs := GrepSpec{
		Path:  os.Getenv("GOPATH") + "/src/github.com/mp1/logs",
		Query: grepQuery,
	}
	g := Grep{Gcache: nil}
	var gr GrepResult
	err := g.Parse(gs, &gr)
	if err != nil {
		t.Fatal(err)
	}

	// run command by exec
	logFullPath := gs.Path + "/" + logFilename
	f, err := os.Open(logFullPath)
	if err != nil {
		t.Fatal(err)
	}

	groundTruthOut := bytes.NewBuffer(nil)
	groundTruthErr := bytes.NewBuffer(nil)

	fields := strings.Fields(gs.Query)
	cmd := exec.Command(fields[0], fields[1:]...)
	cmd.Stdin = f
	cmd.Stdout = groundTruthOut
	cmd.Stderr = groundTruthErr

	if err := cmd.Run(); err != nil {
		t.Log(err)
	}

	// check
	if gr.Result != groundTruthOut.String() {
		t.Log("Not equal to stdout. Errors might have occurred")
		if gr.Result != groundTruthErr.String() {
			t.Fatal("Not equal to either")
		}
	}

}

func TestCorrectness(t *testing.T) {
	grepQuerys := []string{"grep haha", "grep -e [0-9]\\+.*haha", "grep -e \"[haha\""}
	for _, gq := range grepQuerys {
		checkRegex(t, gq, "machine.7.log")
	}
}
