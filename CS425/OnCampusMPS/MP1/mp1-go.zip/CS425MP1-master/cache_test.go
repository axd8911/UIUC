package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	cache "github.com/patrickmn/go-cache"
)

func TestCache(t *testing.T) {
	g := Grep{Gcache: cache.New(10*time.Minute, 15*time.Minute)}

	gs := GrepSpec{
		Path:  os.Getenv("GOPATH") + "/src/github.com/mp1/logs",
		Query: "grep haha",
	}
	if _, found := g.Gcache.Get(gs.Query); found {
		t.Fatal("cache should not contain query")
	}
	var gr GrepResult
	err := g.Parse(gs, &gr) // carry out parse
	err = g.Parse(gs, &gr)  // carry out parse again: should see Cache HIT
	if err != nil {
		t.Fatal(err)
	}
	// time.Sleep(time.Second * 1)
	if _, found := g.Gcache.Get(gs.Query); !found {
		t.Fatal("cache should contain query")
	}

	// touch the file to change ModTime
	filename := gs.Path + "/" + filepath.Base(gr.Filename)
	cmd := exec.Command("touch", filename)
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}
	err = g.Parse(gs, &gr) // parse again: we should see "Cache MISS"
	if err != nil {
		t.Fatal(err)
	}
}
