'''
make sure you use it in the "mp1/py_utility" directory.
after running the script you should have a folder called "logs", containing "machine.i.log"s.
specific the number of logs you would like to generate in cli argument
thx
'''



import sys
num_logs = int(sys.argv[1]) if len(sys.argv) > 1 else 5 # subject to change

from pathlib import Path
import random
random.seed(12345)
from random import shuffle

paths = []
pathlist = Path("raw_logs").glob('*')
for path in pathlist:
    if path.is_file() and not path.name.startswith('.') and not path.is_symlink():
        path = str(path)
        paths.append(path)

assert len(paths) > num_logs
shuffle(paths)

bins = [[] for _ in range(num_logs)]
for i, p in enumerate(paths):
    bins[i % num_logs].append(p)
shuffle(bins)

import fileinput
for log_num in range(num_logs):
    log_filename = "../logs/machine.{}.log".format(log_num)
    with open(log_filename, "wb") as fo:
        print(bins[log_num])
        fi = fileinput.input(bins[log_num], mode='rb')
        for line in fi:
            fo.write(line)

# document file sizes
import os
for p in Path("logs").glob('*'):
    n = p.name
    size = os.path.getsize(str(p))
    print("{}, {}".format(n, size))