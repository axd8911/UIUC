import numpy as np
import matplotlib.pyplot as plt

n_line = [28, 956, 59844, 327351, 2545536, 3928824]
s_cmd = {
    28: [0.081, 0.091, 0.091, 0.090, 0.090, 0.092],
    956:[0.086, 0.086, 0.085, 0.084, 0.085, .0086],
    59844:[0.487, 0.492, 0.492, 0.487, 0.494, 0.482],
    327351:[0.670, 0.673, 0.669, 0.678, 0.671, 0.672],
    2545536:[0.996, 0.990, 0.974, 1.009, 0.972, 0.995],
    3928824:[1.324, 1.377, 1.365, 1.353, 1.379, 1.394]
    }
s_cmd_cache = {
    28:[0.010, 0.010, 0.004, 0.009, 0.010, 0.009],
    956:[0.010, 0.010, 0.010, 0.010, 0.010, 0.011],
    59844:[0.032, 0.033, 0.033, 0.034, 0.032 , 0.032],
    327351:[0.186, 0.191, 0.188, 0.192, 0.192, 0.200],
    2545536:[0.559, 0.541, 0.536, 0.549, 0.567, 0.575],
    3928824:[0.908, 0.849, 0.863, 0.848, 0.886, 0.886]
    }

print("normal")
avg_t, avg_t_cache = [], []
avg_std, avg_std_cache = [], []
for line, ts in s_cmd.items():
    avg_t.append(np.mean(ts))
    avg_std.append(np.std(ts))
    print(line, avg_t[-1], avg_std[-1])
print("cache")
for line, ts in s_cmd_cache.items():
    avg_t_cache.append(np.mean(ts))
    avg_std_cache.append(np.std(ts))
    print(line, avg_t_cache[-1], avg_std_cache[-1])

fig = plt.figure()
fig.suptitle("Latency of Distributed Grep")

plt.subplot(2, 2, 1)
plt.plot(n_line, avg_t, "--o", label="non-cahce")
plt.plot(n_line, avg_t_cache, "--o", label="cahce")
plt.ylabel("second")
plt.xlabel("matched lines")
plt.legend()
plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))


plt.subplot(2, 2, 2)
plt.plot(n_line, avg_t, "--o", label="non-cahce")
plt.plot(n_line, avg_t_cache, "--o", label="cahce")
plt.ylabel("second")
plt.xlabel("matched lines")
plt.xscale('log')

plt.subplot(2, 2, 3)
plt.plot(n_line, avg_std, "--o", label="non-cahce")
plt.plot(n_line, avg_std_cache, "--o", label="cahce")
plt.ylabel("std of time")
plt.xlabel("matched lines")
plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))

plt.subplot(2, 2, 4)
plt.plot(n_line, avg_std, "--o", label="non-cahce")
plt.plot(n_line, avg_std_cache, "--o", label="cahce")
plt.ylabel("std of time")
plt.xlabel("matched lines")
plt.xscale('log')

plt.show()