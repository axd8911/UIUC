'''
This script run grep on the files in raw_logs
and save the result to the folder "ground_truth"
'''

import sys
import os
from pathlib import Path
import subprocess
import re
cmd = sys.argv[1] # a command

print("Python Running Cmd: ", cmd)

# remove everything in ground_truth
os.system("rm ground_truth/*")

paths = []
pathlist = Path("raw_logs").glob('*')
for path in pathlist:
    if path.is_file() and not path.name.startswith('.') and not path.is_symlink():
        path = str(path)
        paths.append(path)

for path in paths:
    filename = os.path.basename(path)
    log_number = re.findall(r"\d+", filename)[0]
    filename = "machine.{}.log".format(log_number)
    with open(path, "rb") as f:
        with open("ground_truth/"+filename, "wb") as wf:
            p = subprocess.Popen(cmd.split(), shell=False, stdin=f, stdout=wf, stderr=wf)

exit(0)