import paramiko
import os
import sys

username = sys.argv[1]
password = sys.argv[2]

ssh = paramiko.SSHClient()
ssh.load_host_keys(os.path.expanduser(os.path.join("~", ".ssh", "known_hosts")))
with open(".pgreprc") as f:
    for i, line in enumerate(f):
        line = line.split()
        assert len(line) == 2
        hostname, path = line[0], line[1]
        print(hostname)
        print(path)
        t = paramiko.Transport((hostname, 22))
        t.connect(username=username, password=password)
        sftp = paramiko.SFTPClient.from_transport(t)
        remote_filename = "machine.{}.log".format(i + 1)
        local_filename = "vm{}.log".format(i + 1)
        sftp.put(os.path.join("../raw_logs", local_filename), os.path.join(path, remote_filename))
        sftp.close()
        ssh.close()
