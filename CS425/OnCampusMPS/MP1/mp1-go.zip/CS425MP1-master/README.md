## Distributed Grep

### Getting Started

```shell
git clone https://gitlab.engr.illinois.edu/gdou2/CS425MP1.git
go build
```

### Tutorial

Install ```dep```

```shell
On Mac:
	brew install dep
	brew upgrade dep
Others:
	curl https://raw.githubusercontent.com/golang/dep/master/install.sh | sh
```

Install dependecy
```shell
dep ensure
```

Use ```.pgreprc``` to specify servers' address and log path.

```shell
cs.illinois.edu /home/logs
```

For servers:
```shell
./mp1 -c
```

For client:

```shell
./mp1 -q "grep -e go”
```

### testing scheme
Run ```py_utility/make_ground_truth.py <cmd>``` to build ground truth.

Run ```./mp1``` with the flag ```-f``` to divert output to files. 

Compare the corresponding files. 

### Manual


| Command              |     Type         | Description |
| -----------------    | -----------------| ---------- |
| ```-port, -p```	   | Optional         | communication port (default: 6666) |
| ```-query, -q```	   | Required (Client)| grep command |
| ```-cache, -c```     | Optional (Server)| enable cache for servers |
| ```-tofile, -f```    | Optional (Client)| save query results to a file |
| ```-cacheT, -cat```  | Optional (Server)| cache Expiration time in minutes (default: 10) |
| ```-cleanT, -clt```  | Optional (Server)| cache clean-up interval in minutes (default: 15) |
| ```-help, -h```      | Optional         | show help |
| ```-version, -v```   | Optional         | print the version |

### Authors
Guohao Dou, Zhenbang Wang
