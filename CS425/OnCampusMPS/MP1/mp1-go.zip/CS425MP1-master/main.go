package main

import (
	"bufio"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/mp1/logging"
	"github.com/urfave/cli"
)

// MachineSpec specifies the address of logs
type MachineSpec struct {
	URL  string
	Path string
}

// Flags provides parameters
type Flags struct {
	Port            int
	Query           string
	ToFile          bool
	FlagCache       bool
	CacheExpiration int
	CleanInterval   int
}

func main() {
	// business logic:
	// with "-r "grep ..."" -> send request
	// without "-r" -> launch server
	FLAGS := new(Flags)
	app := cli.NewApp()
	app.Name = "pentagrep"
	app.Usage = "store .pgreprc at $HOME or cwd."
	app.Flags = []cli.Flag{
		cli.IntFlag{
			Name:        "port, p",
			Value:       6666,
			Usage:       "communication port",
			Destination: &FLAGS.Port,
		},
		cli.StringFlag{
			Name:        "query, q",
			Usage:       "grep command", // the whole grep command
			Destination: &FLAGS.Query,
		},
		cli.BoolFlag{
			Name:        "cache, c",
			Usage:       "enable cache for servers",
			Destination: &FLAGS.FlagCache,
		},
		cli.BoolFlag{
			Name:        "tofile, f",
			Usage:       "save query results to a file",
			Destination: &FLAGS.ToFile,
		},
		cli.IntFlag{
			Name:        "cacheT, cat",
			Value:       10,
			Usage:       "cache Expiration time in minutes",
			Destination: &FLAGS.CacheExpiration,
		},
		cli.IntFlag{
			Name:        "cleanT, clt",
			Value:       15,
			Usage:       "cache clean-up interval in minutes",
			Destination: &FLAGS.CleanInterval,
		},
	}
	app.Action = func(c *cli.Context) error {
		rcPath := ".pgreprc"
		var configPath string
		if _, err := os.Stat(rcPath); err == nil {
			configPath = rcPath
		} else {
			homeDir := os.Getenv("HOME")
			rcPath = filepath.Join(homeDir, ".pgreprc")
			if _, err = os.Stat(rcPath); err == nil {
				configPath = rcPath
			}
		}
		if configPath == "" { // both CWD and home failed. show warning
			logging.Warning.Println("missing configuration file(.pgreprc).")
			logging.Warning.Println("please put a valid config file either at $HOME or $PWD(current working directory)")
			logging.Info.Println(`
				To function properly, pentagrep needs to know 
					(1) urls of all machines 
					(2) directory path under which logs are to be found
				Such information is stored in .pgreprc, located either at $HOME or current working directory.
				The format is like <Machine URL> <Path> for each line of .pgreprc
				For example:
					zeminj1s@linux.ews.illinois.edu /home/zeminj1s/Documents
			`)
			logging.Info.Println("Thanks for using my CLI")
			os.Exit(1)
		}

		logging.Info.Printf("Using .pgreprc at %s\n", configPath)

		// extract machine urls & paths
		ms := make([]MachineSpec, 0)
		rc, _ := os.Open(configPath)
		sc := bufio.NewScanner(rc)
		for sc.Scan() {
			line := sc.Text()
			if strings.HasPrefix(line, "//") {
				continue
			}
			fields := strings.Fields(line)
			if len(fields) != 2 {
				logging.Warning.Println("Bad .pgreprc syntax")
				os.Exit(1)
			}
			ms = append(ms, MachineSpec{
				URL:  fields[0],
				Path: fields[1],
			})
		}
		if len(ms) == 0 {
			logging.Warning.Println("Empty .pgreprc!")
			os.Exit(1)
		}

		if FLAGS.Query != "" {
			// handle client call
			HandleClients(ms, FLAGS)
		} else {
			HandleServer(FLAGS)
		}
		return nil
	}

	err := app.Run(os.Args)
	if err != nil {
		log.Fatal(err)
	}

}
